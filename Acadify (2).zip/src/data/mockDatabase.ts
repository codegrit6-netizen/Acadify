// Comprehensive Mock Database for Acadify Demo

export interface Student {
  id: string;
  name: string;
  email: string;
  phone: string;
  type: 'student';
  avatar?: string;
  rollNumber: string;
  class: string;
  stream: string;
  year: number;
  semester: number;
  parentId: string;
  dateOfBirth: string;
  address: string;
  subjects: string[];
  attendanceStats: {
    totalClasses: number;
    attendedClasses: number;
    percentage: number;
  };
  grades: { subject: string; grade: string; marks: number }[];
}

export interface Teacher {
  id: string;
  name: string;
  email: string;
  phone: string;
  type: 'teacher';
  avatar?: string;
  employeeId: string;
  department: string;
  qualification: string;
  experience: number;
  subjectsTaught: string[];
  classesAssigned: string[];
  schedule: {
    day: string;
    periods: { time: string; subject: string; class: string; room: string }[];
  }[];
}

export interface Parent {
  id: string;
  name: string;
  email: string;
  phone: string;
  type: 'parent';
  avatar?: string;
  occupation: string;
  relationship: string;
  childrenIds: string[];
  address: string;
  emergencyContact: string;
}

export interface Admin {
  id: string;
  name: string;
  email: string;
  phone: string;
  type: 'admin';
  avatar?: string;
  employeeId: string;
  role: string;
  department: string;
  permissions: string[];
  yearsOfService: number;
}

export interface Class {
  id: string;
  name: string;
  stream: string;
  year: number;
  section: string;
  classTeacher: string;
  studentCount: number;
  subjects: string[];
  room: string;
}

export interface Subject {
  id: string;
  name: string;
  code: string;
  credits: number;
  department: string;
  prerequisites?: string[];
}

export interface AttendanceRecord {
  id: string;
  studentId: string;
  classId: string;
  subject: string;
  date: string;
  status: 'present' | 'absent' | 'late';
  markedBy: string;
  timestamp: string;
}

export interface Announcement {
  id: string;
  title: string;
  content: string;
  author: string;
  authorName: string;
  authorType: 'teacher' | 'admin';
  targetAudience: 'all' | 'students' | 'teachers' | 'parents' | string[]; // can be 'all' or specific class IDs
  priority: 'low' | 'medium' | 'high' | 'urgent';
  category: 'general' | 'academic' | 'events' | 'holidays' | 'exams' | 'assignments' | 'administrative';
  createdAt: string;
  updatedAt?: string;
  expiresAt?: string;
  isActive: boolean;
  attachments?: { name: string; url: string; type: string }[];
  readBy?: string[]; // user IDs who have read the announcement
}

// Mock Students Data
export const students: Student[] = [
  {
    id: 'STU001',
    name: 'Arjun Patel',
    email: 'arjun.patel@student.acadify.edu',
    phone: '+91 98765 43210',
    type: 'student',
    rollNumber: 'CS21001',
    class: 'CS-A',
    stream: 'Computer Science',
    year: 2,
    semester: 4,
    parentId: 'PAR001',
    dateOfBirth: '2003-05-15',
    address: '123 Tech Park, Ahmedabad, Gujarat 380001',
    subjects: ['Data Structures', 'Database Systems', 'Web Development', 'Computer Networks', 'Software Engineering'],
    attendanceStats: {
      totalClasses: 120,
      attendedClasses: 102,
      percentage: 85
    },
    grades: [
      { subject: 'Data Structures', grade: 'A', marks: 88 },
      { subject: 'Database Systems', grade: 'A-', marks: 82 },
      { subject: 'Web Development', grade: 'B+', marks: 79 },
      { subject: 'Computer Networks', grade: 'A', marks: 86 },
      { subject: 'Software Engineering', grade: 'A-', marks: 83 }
    ]
  },
  {
    id: 'STU002',
    name: 'Priya Sharma',
    email: 'priya.sharma@student.acadify.edu',
    phone: '+91 98765 43211',
    type: 'student',
    rollNumber: 'EC21015',
    class: 'EC-B',
    stream: 'Electronics',
    year: 2,
    semester: 4,
    parentId: 'PAR002',
    dateOfBirth: '2003-08-22',
    address: '456 Innovation Street, Pune, Maharashtra 411001',
    subjects: ['Digital Electronics', 'Signal Processing', 'Microprocessors', 'Communication Systems', 'Control Systems'],
    attendanceStats: {
      totalClasses: 115,
      attendedClasses: 108,
      percentage: 94
    },
    grades: [
      { subject: 'Digital Electronics', grade: 'A+', marks: 92 },
      { subject: 'Signal Processing', grade: 'A', marks: 87 },
      { subject: 'Microprocessors', grade: 'A', marks: 89 },
      { subject: 'Communication Systems', grade: 'A-', marks: 84 },
      { subject: 'Control Systems', grade: 'A', marks: 88 }
    ]
  },
  {
    id: 'STU003',
    name: 'Ravi Kumar',
    email: 'ravi.kumar@student.acadify.edu',
    phone: '+91 98765 43212',
    type: 'student',
    rollNumber: 'ME21025',
    class: 'ME-A',
    stream: 'Mechanical Engineering',
    year: 1,
    semester: 2,
    parentId: 'PAR003',
    dateOfBirth: '2004-01-10',
    address: '789 Engineering Colony, Chennai, Tamil Nadu 600001',
    subjects: ['Engineering Mechanics', 'Thermodynamics', 'Material Science', 'Manufacturing Processes', 'Engineering Drawing'],
    attendanceStats: {
      totalClasses: 100,
      attendedClasses: 78,
      percentage: 78
    },
    grades: [
      { subject: 'Engineering Mechanics', grade: 'B+', marks: 76 },
      { subject: 'Thermodynamics', grade: 'B', marks: 72 },
      { subject: 'Material Science', grade: 'B+', marks: 78 },
      { subject: 'Manufacturing Processes', grade: 'A-', marks: 81 },
      { subject: 'Engineering Drawing', grade: 'A', marks: 85 }
    ]
  }
];

// Mock Teachers Data
export const teachers: Teacher[] = [
  {
    id: 'TCH001',
    name: 'Dr. Rajesh Gupta',
    email: 'rajesh.gupta@acadify.edu',
    phone: '+91 98765 54321',
    type: 'teacher',
    employeeId: 'EMP001',
    department: 'Computer Science',
    qualification: 'Ph.D. in Computer Science',
    experience: 15,
    subjectsTaught: ['Data Structures', 'Algorithms', 'Software Engineering', 'Database Systems'],
    classesAssigned: ['CS-A', 'CS-B'],
    schedule: [
      {
        day: 'Monday',
        periods: [
          { time: '09:00-10:00', subject: 'Data Structures', class: 'CS-A', room: 'Room 101' },
          { time: '11:00-12:00', subject: 'Algorithms', class: 'CS-B', room: 'Room 102' },
          { time: '14:00-15:00', subject: 'Database Systems', class: 'CS-A', room: 'Lab 201' }
        ]
      },
      {
        day: 'Tuesday',
        periods: [
          { time: '10:00-11:00', subject: 'Software Engineering', class: 'CS-A', room: 'Room 101' },
          { time: '15:00-16:00', subject: 'Data Structures', class: 'CS-B', room: 'Room 103' }
        ]
      }
    ]
  },
  {
    id: 'TCH002',
    name: 'Prof. Meera Joshi',
    email: 'meera.joshi@acadify.edu',
    phone: '+91 98765 54322',
    type: 'teacher',
    employeeId: 'EMP002',
    department: 'Electronics',
    qualification: 'M.Tech in Electronics & Communication',
    experience: 12,
    subjectsTaught: ['Digital Electronics', 'Signal Processing', 'Communication Systems', 'Microprocessors'],
    classesAssigned: ['EC-A', 'EC-B'],
    schedule: [
      {
        day: 'Monday',
        periods: [
          { time: '10:00-11:00', subject: 'Digital Electronics', class: 'EC-A', room: 'Room 201' },
          { time: '13:00-14:00', subject: 'Signal Processing', class: 'EC-B', room: 'Lab 301' }
        ]
      }
    ]
  },
  {
    id: 'TCH003',
    name: 'Dr. Amit Singh',
    email: 'amit.singh@acadify.edu',
    phone: '+91 98765 54323',
    type: 'teacher',
    employeeId: 'EMP003',
    department: 'Mechanical Engineering',
    qualification: 'Ph.D. in Mechanical Engineering',
    experience: 18,
    subjectsTaught: ['Thermodynamics', 'Fluid Mechanics', 'Heat Transfer', 'Machine Design'],
    classesAssigned: ['ME-A', 'ME-B'],
    schedule: [
      {
        day: 'Monday',
        periods: [
          { time: '09:00-10:00', subject: 'Thermodynamics', class: 'ME-A', room: 'Room 301' },
          { time: '11:00-12:00', subject: 'Fluid Mechanics', class: 'ME-B', room: 'Room 302' }
        ]
      }
    ]
  }
];

// Mock Parents Data
export const parents: Parent[] = [
  {
    id: 'PAR001',
    name: 'Vikram Patel',
    email: 'vikram.patel@gmail.com',
    phone: '+91 98765 67890',
    type: 'parent',
    occupation: 'Software Engineer',
    relationship: 'Father',
    childrenIds: ['STU001'],
    address: '123 Tech Park, Ahmedabad, Gujarat 380001',
    emergencyContact: '+91 98765 67891'
  },
  {
    id: 'PAR002',
    name: 'Sunita Sharma',
    email: 'sunita.sharma@gmail.com',
    phone: '+91 98765 67892',
    type: 'parent',
    occupation: 'Doctor',
    relationship: 'Mother',
    childrenIds: ['STU002'],
    address: '456 Innovation Street, Pune, Maharashtra 411001',
    emergencyContact: '+91 98765 67893'
  },
  {
    id: 'PAR003',
    name: 'Lakshmi Kumar',
    email: 'lakshmi.kumar@gmail.com',
    phone: '+91 98765 67894',
    type: 'parent',
    occupation: 'Teacher',
    relationship: 'Mother',
    childrenIds: ['STU003'],
    address: '789 Engineering Colony, Chennai, Tamil Nadu 600001',
    emergencyContact: '+91 98765 67895'
  }
];

// Mock Admins Data
export const admins: Admin[] = [
  {
    id: 'ADM001',
    name: 'Dr. Kavitha Nair',
    email: 'kavitha.nair@acadify.edu',
    phone: '+91 98765 12345',
    type: 'admin',
    employeeId: 'ADM001',
    role: 'Academic Director',
    department: 'Administration',
    permissions: ['user_management', 'system_reports', 'curriculum_management', 'attendance_oversight'],
    yearsOfService: 20
  },
  {
    id: 'ADM002',
    name: 'Mr. Suresh Reddy',
    email: 'suresh.reddy@acadify.edu',
    phone: '+91 98765 12346',
    type: 'admin',
    employeeId: 'ADM002',
    role: 'IT Administrator',
    department: 'Information Technology',
    permissions: ['system_settings', 'technical_support', 'data_management'],
    yearsOfService: 8
  }
];

// Mock Classes Data
export const classes: Class[] = [
  {
    id: 'CS-A',
    name: 'Computer Science A',
    stream: 'Computer Science',
    year: 2,
    section: 'A',
    classTeacher: 'TCH001',
    studentCount: 45,
    subjects: ['Data Structures', 'Database Systems', 'Web Development', 'Computer Networks', 'Software Engineering'],
    room: 'Room 101'
  },
  {
    id: 'EC-B',
    name: 'Electronics B',
    stream: 'Electronics',
    year: 2,
    section: 'B',
    classTeacher: 'TCH002',
    studentCount: 40,
    subjects: ['Digital Electronics', 'Signal Processing', 'Microprocessors', 'Communication Systems', 'Control Systems'],
    room: 'Room 201'
  },
  {
    id: 'ME-A',
    name: 'Mechanical Engineering A',
    stream: 'Mechanical Engineering',
    year: 1,
    section: 'A',
    classTeacher: 'TCH003',
    studentCount: 50,
    subjects: ['Engineering Mechanics', 'Thermodynamics', 'Material Science', 'Manufacturing Processes', 'Engineering Drawing'],
    room: 'Room 301'
  }
];

// Mock Subjects Data
export const subjects: Subject[] = [
  { id: 'DS001', name: 'Data Structures', code: 'CS201', credits: 4, department: 'Computer Science' },
  { id: 'DB001', name: 'Database Systems', code: 'CS202', credits: 4, department: 'Computer Science' },
  { id: 'WD001', name: 'Web Development', code: 'CS203', credits: 3, department: 'Computer Science' },
  { id: 'CN001', name: 'Computer Networks', code: 'CS204', credits: 4, department: 'Computer Science' },
  { id: 'SE001', name: 'Software Engineering', code: 'CS205', credits: 3, department: 'Computer Science' },
  { id: 'DE001', name: 'Digital Electronics', code: 'EC201', credits: 4, department: 'Electronics' },
  { id: 'SP001', name: 'Signal Processing', code: 'EC202', credits: 4, department: 'Electronics' },
  { id: 'MP001', name: 'Microprocessors', code: 'EC203', credits: 3, department: 'Electronics' },
  { id: 'CS001', name: 'Communication Systems', code: 'EC204', credits: 4, department: 'Electronics' },
  { id: 'CT001', name: 'Control Systems', code: 'EC205', credits: 3, department: 'Electronics' }
];

// Mock Attendance Records
export const attendanceRecords: AttendanceRecord[] = [
  {
    id: 'ATT001',
    studentId: 'STU001',
    classId: 'CS-A',
    subject: 'Data Structures',
    date: '2024-09-05',
    status: 'present',
    markedBy: 'TCH001',
    timestamp: '2024-09-05T09:05:00Z'
  },
  {
    id: 'ATT002',
    studentId: 'STU002',
    classId: 'EC-B',
    subject: 'Digital Electronics',
    date: '2024-09-05',
    status: 'present',
    markedBy: 'TCH002',
    timestamp: '2024-09-05T10:05:00Z'
  },
  {
    id: 'ATT003',
    studentId: 'STU003',
    classId: 'ME-A',
    subject: 'Thermodynamics',
    date: '2024-09-05',
    status: 'absent',
    markedBy: 'TCH003',
    timestamp: '2024-09-05T09:05:00Z'
  },
  {
    id: 'ATT004',
    studentId: 'STU001',
    classId: 'CS-A',
    subject: 'Database Systems',
    date: '2024-09-04',
    status: 'present',
    markedBy: 'TCH001',
    timestamp: '2024-09-04T11:05:00Z'
  },
  {
    id: 'ATT005',
    studentId: 'STU002',
    classId: 'EC-B',
    subject: 'Signal Processing',
    date: '2024-09-04',
    status: 'late',
    markedBy: 'TCH002',
    timestamp: '2024-09-04T10:15:00Z'
  },
  {
    id: 'ATT006',
    studentId: 'STU003',
    classId: 'ME-A',
    subject: 'Engineering Mechanics',
    date: '2024-09-04',
    status: 'absent',
    markedBy: 'TCH003',
    timestamp: '2024-09-04T09:05:00Z'
  },
  {
    id: 'ATT007',
    studentId: 'STU001',
    classId: 'CS-A',
    subject: 'Web Development',
    date: '2024-09-03',
    status: 'present',
    markedBy: 'TCH001',
    timestamp: '2024-09-03T14:05:00Z'
  },
  {
    id: 'ATT008',
    studentId: 'STU003',
    classId: 'ME-A',
    subject: 'Material Science',
    date: '2024-09-03',
    status: 'absent',
    markedBy: 'TCH003',
    timestamp: '2024-09-03T10:05:00Z'
  }
];

// Mock Assignment and Activity Data
export interface Assignment {
  id: string;
  title: string;
  subject: string;
  classId: string;
  teacherId: string;
  dueDate: string;
  maxMarks: number;
  description: string;
  submissions: {
    studentId: string;
    submittedAt?: string;
    marks?: number;
    status: 'submitted' | 'pending' | 'late';
  }[];
}

export const assignments: Assignment[] = [
  {
    id: 'ASG001',
    title: 'Database Design Project',
    subject: 'Database Systems',
    classId: 'CS-A',
    teacherId: 'TCH001',
    dueDate: '2024-09-20',
    maxMarks: 100,
    description: 'Design and implement a complete database system for a library management system',
    submissions: [
      { studentId: 'STU001', submittedAt: '2024-09-18T10:30:00Z', marks: 85, status: 'submitted' },
      { studentId: 'STU002', status: 'pending' }
    ]
  },
  {
    id: 'ASG002',
    title: 'Circuit Analysis Assignment',
    subject: 'Digital Electronics',
    classId: 'EC-B',
    teacherId: 'TCH002',
    dueDate: '2024-09-15',
    maxMarks: 50,
    description: 'Analyze given digital circuits and provide truth tables',
    submissions: [
      { studentId: 'STU002', submittedAt: '2024-09-14T16:45:00Z', marks: 47, status: 'submitted' }
    ]
  },
  {
    id: 'ASG003',
    title: 'Thermodynamics Problem Set',
    subject: 'Thermodynamics',
    classId: 'ME-A',
    teacherId: 'TCH003',
    dueDate: '2024-09-12',
    maxMarks: 75,
    description: 'Solve thermodynamic cycles and efficiency calculations',
    submissions: [
      { studentId: 'STU003', submittedAt: '2024-09-13T09:20:00Z', marks: 45, status: 'late' }
    ]
  }
];

// Mock Announcements Data
export const announcements: Announcement[] = [
  {
    id: 'ANN001',
    title: 'Mid-Term Examinations Schedule Released',
    content: 'Dear Students, The mid-term examination schedule for all departments has been finalized. Exams will commence from September 15th, 2024. Please check your individual timetables on the student portal. Ensure you have your admit cards ready and arrive 30 minutes before the exam time. Good luck with your preparations!',
    author: 'ADM001',
    authorName: 'Dr. Kavitha Nair',
    authorType: 'admin',
    targetAudience: 'all',
    priority: 'high',
    category: 'exams',
    createdAt: '2024-09-01T10:00:00Z',
    isActive: true,
    readBy: ['STU001', 'TCH001']
  },
  {
    id: 'ANN002',
    title: 'New Assignment: Database Design Project',
    content: 'Students of CS-A, you have a new assignment for Database Systems. Design and implement a complete database system for a library management system. Submission deadline is September 20th, 2024. Project guidelines and requirements are uploaded on the course portal.',
    author: 'TCH001',
    authorName: 'Dr. Rajesh Gupta',
    authorType: 'teacher',
    targetAudience: ['CS-A'],
    priority: 'medium',
    category: 'assignments',
    createdAt: '2024-09-03T14:30:00Z',
    isActive: true,
    readBy: ['STU001']
  },
  {
    id: 'ANN003',
    title: 'Technical Fest 2024 - TechnoVision',
    content: 'We are excited to announce TechnoVision 2024, our annual technical festival! The event will be held from September 25-27, 2024. Various competitions including coding contests, robotics, circuit debugging, and project exhibitions will be conducted. Registration is now open. Prizes worth ₹2,00,000 to be won!',
    author: 'ADM001',
    authorName: 'Dr. Kavitha Nair',
    authorType: 'admin',
    targetAudience: 'all',
    priority: 'medium',
    category: 'events',
    createdAt: '2024-08-28T09:00:00Z',
    isActive: true,
    expiresAt: '2024-09-27T23:59:59Z',
    readBy: ['STU001', 'STU002', 'TCH001', 'TCH002']
  },
  {
    id: 'ANN004',
    title: 'Holiday Notice: Gandhi Jayanti',
    content: 'The college will remain closed on October 2nd, 2024 (Wednesday) on account of Gandhi Jayanti. Regular classes will resume from October 3rd, 2024. Have a peaceful holiday!',
    author: 'ADM002',
    authorName: 'Mr. Suresh Reddy',
    authorType: 'admin',
    targetAudience: 'all',
    priority: 'low',
    category: 'holidays',
    createdAt: '2024-09-25T11:00:00Z',
    isActive: true,
    expiresAt: '2024-10-03T00:00:00Z'
  },
  {
    id: 'ANN005',
    title: 'Parent-Teacher Meeting Scheduled',
    content: 'Dear Parents, We are organizing a parent-teacher meeting on September 18th, 2024, from 10:00 AM to 4:00 PM. This is an excellent opportunity to discuss your child\'s academic progress and address any concerns. Please confirm your attendance by replying to this announcement.',
    author: 'TCH002',
    authorName: 'Prof. Meera Joshi',
    authorType: 'teacher',
    targetAudience: 'parents',
    priority: 'high',
    category: 'general',
    createdAt: '2024-09-04T16:00:00Z',
    isActive: true,
    readBy: ['PAR001', 'PAR002']
  },
  {
    id: 'ANN006',
    title: 'Library Extended Hours During Exams',
    content: 'The college library will extend its working hours during the examination period. From September 15th to September 30th, the library will be open from 8:00 AM to 10:00 PM on weekdays and 9:00 AM to 6:00 PM on weekends. Make the most of these extended hours for your exam preparation.',
    author: 'ADM001',
    authorName: 'Dr. Kavitha Nair',
    authorType: 'admin',
    targetAudience: 'students',
    priority: 'medium',
    category: 'academic',
    createdAt: '2024-09-02T12:00:00Z',
    isActive: true,
    expiresAt: '2024-09-30T23:59:59Z'
  },
  {
    id: 'ANN007',
    title: 'Urgent: Lab Safety Protocol Update',
    content: 'URGENT: New safety protocols have been implemented in all engineering labs effective immediately. All students and faculty must complete the online safety certification before accessing any lab. The certification link is available on the college portal. Non-compliance will result in lab access suspension.',
    author: 'ADM002',
    authorName: 'Mr. Suresh Reddy',
    authorType: 'admin',
    targetAudience: 'all',
    priority: 'urgent',
    category: 'administrative',
    createdAt: '2024-09-05T08:00:00Z',
    isActive: true
  }
];

// Helper function to get user by ID and type
export const getUserById = (userId: string, userType?: string): Student | Teacher | Parent | Admin | null => {
  let allUsers: (Student | Teacher | Parent | Admin)[] = [];
  
  if (!userType || userType === 'student') {
    allUsers = allUsers.concat(students);
  }
  if (!userType || userType === 'teacher') {
    allUsers = allUsers.concat(teachers);
  }
  if (!userType || userType === 'parent') {
    allUsers = allUsers.concat(parents);
  }
  if (!userType || userType === 'admin') {
    allUsers = allUsers.concat(admins);
  }

  return allUsers.find(user => user.id === userId) || null;
};

// Helper function to get student's parent
export const getStudentParent = (studentId: string): Parent | null => {
  const student = students.find(s => s.id === studentId);
  if (!student) return null;
  return parents.find(p => p.id === student.parentId) || null;
};

// Helper function to get parent's children
export const getParentChildren = (parentId: string): Student[] => {
  const parent = parents.find(p => p.id === parentId);
  if (!parent) return [];
  return students.filter(s => parent.childrenIds.includes(s.id));
};

// Helper function to get teacher's students
export const getTeacherStudents = (teacherId: string): Student[] => {
  const teacher = teachers.find(t => t.id === teacherId);
  if (!teacher) return [];
  return students.filter(s => teacher.classesAssigned.includes(s.class));
};

// Helper function to get class students
export const getClassStudents = (classId: string): Student[] => {
  return students.filter(s => s.class === classId);
};

// Helper function to get announcements for a user
export const getAnnouncementsForUser = (userId: string, userType: string, userClass?: string): Announcement[] => {
  const now = new Date();
  
  return announcements.filter(announcement => {
    // Check if announcement is active and not expired
    if (!announcement.isActive) return false;
    if (announcement.expiresAt && new Date(announcement.expiresAt) < now) return false;
    
    // Check target audience
    if (announcement.targetAudience === 'all') return true;
    if (announcement.targetAudience === userType + 's') return true;
    
    // For class-specific announcements
    if (Array.isArray(announcement.targetAudience)) {
      if (userClass && announcement.targetAudience.includes(userClass)) return true;
    }
    
    return false;
  }).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
};

// Helper function to get all announcements (for teachers/admins)
export const getAllAnnouncements = (): Announcement[] => {
  return announcements.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
};

// Helper function to mark announcement as read
export const markAnnouncementAsRead = (announcementId: string, userId: string): void => {
  const announcement = announcements.find(a => a.id === announcementId);
  if (announcement) {
    if (!announcement.readBy) announcement.readBy = [];
    if (!announcement.readBy.includes(userId)) {
      announcement.readBy.push(userId);
    }
  }
};

// Helper function to create new announcement
export const createAnnouncement = (announcement: Omit<Announcement, 'id' | 'createdAt' | 'readBy'>): Announcement => {
  const newAnnouncement: Announcement = {
    ...announcement,
    id: `ANN${String(announcements.length + 1).padStart(3, '0')}`,
    createdAt: new Date().toISOString(),
    readBy: []
  };
  
  announcements.unshift(newAnnouncement);
  return newAnnouncement;
};

// Helper function to update announcement
export const updateAnnouncement = (id: string, updates: Partial<Announcement>): Announcement | null => {
  const index = announcements.findIndex(a => a.id === id);
  if (index === -1) return null;
  
  announcements[index] = {
    ...announcements[index],
    ...updates,
    updatedAt: new Date().toISOString()
  };
  
  return announcements[index];
};

// Helper function to delete announcement
export const deleteAnnouncement = (id: string): boolean => {
  const index = announcements.findIndex(a => a.id === id);
  if (index === -1) return false;
  
  announcements.splice(index, 1);
  return true;
};

// Helper function to get student assignments
export const getStudentAssignments = (studentId: string): { assignment: Assignment; submission?: Assignment['submissions'][0] }[] => {
  return assignments.map(assignment => {
    const submission = assignment.submissions.find(s => s.studentId === studentId);
    return { assignment, submission };
  }).filter(({ submission }) => submission);
};

// Helper function to get class assignments
export const getClassAssignments = (classId: string): Assignment[] => {
  return assignments.filter(a => a.classId === classId);
};

// Demo credentials for easy login
export const demoCredentials = {
  students: [
    { id: 'STU001', name: 'Arjun Patel', password: 'arjun123' },
    { id: 'STU002', name: 'Priya Sharma', password: 'priya123' },
    { id: 'STU003', name: 'Ravi Kumar', password: 'ravi123' }
  ],
  teachers: [
    { id: 'TCH001', name: 'Dr. Rajesh Gupta', password: 'rajesh123' },
    { id: 'TCH002', name: 'Prof. Meera Joshi', password: 'meera123' },
    { id: 'TCH003', name: 'Dr. Amit Singh', password: 'amit123' }
  ],
  parents: [
    { id: 'PAR001', name: 'Vikram Patel', password: 'vikram123' },
    { id: 'PAR002', name: 'Sunita Sharma', password: 'sunita123' },
    { id: 'PAR003', name: 'Lakshmi Kumar', password: 'lakshmi123' }
  ],
  admins: [
    { id: 'ADM001', name: 'Dr. Kavitha Nair', password: 'kavitha123' },
    { id: 'ADM002', name: 'Mr. Suresh Reddy', password: 'suresh123' }
  ]
};