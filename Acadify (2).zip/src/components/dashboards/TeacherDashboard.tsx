import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Textarea } from '../ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Calendar } from '../ui/calendar';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../ui/table';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { AnnouncementManagement } from '../announcements/AnnouncementManagement';
import { getUserById } from '../../data/mockDatabase';
import type { Teacher } from '../../data/mockDatabase';
import { 
  QrCode, 
  Users, 
  Calendar as CalendarIcon, 
  Upload, 
  Plus,
  CheckCircle,
  XCircle,
  Clock,
  FileText,
  BarChart3
} from 'lucide-react';

interface TeacherDashboardProps {
  activeTab: string;
  teacherId: string;
}

export function TeacherDashboard({ activeTab, teacherId }: TeacherDashboardProps) {
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());
  const [showQRCode, setShowQRCode] = useState(false);
  const [selectedClass, setSelectedClass] = useState('');
  
  // Get teacher data from database
  const teacher = getUserById(teacherId, 'teacher') as Teacher;

  // Mock data
  const todayClasses = [
    { id: 1, subject: 'Mathematics', time: '09:00 AM', room: 'Room 101', students: 35, attended: 32 },
    { id: 2, subject: 'Physics', time: '11:00 AM', room: 'Lab 203', students: 30, attended: 0 },
    { id: 3, subject: 'Chemistry', time: '02:00 PM', room: 'Lab 105', students: 28, attended: 0 },
  ];

  const students = [
    { id: 'STU001', name: 'John Doe', status: 'present', time: '09:05 AM' },
    { id: 'STU002', name: 'Jane Smith', status: 'present', time: '09:03 AM' },
    { id: 'STU003', name: 'Mike Johnson', status: 'absent', time: '-' },
    { id: 'STU004', name: 'Sarah Wilson', status: 'present', time: '09:07 AM' },
    { id: 'STU005', name: 'David Brown', status: 'late', time: '09:15 AM' },
  ];

  const classReports = [
    { subject: 'Mathematics', totalClasses: 25, avgAttendance: 92 },
    { subject: 'Physics', totalClasses: 20, avgAttendance: 88 },
    { subject: 'Chemistry', totalClasses: 22, avgAttendance: 85 },
  ];

  const generateQRCode = (classId: number) => {
    setShowQRCode(true);
    // In a real app, this would generate a unique QR code for the session
  };

  if (!teacher) {
    return <div>Teacher not found</div>;
  }

  if (activeTab === 'announcements') {
    return <AnnouncementManagement user={teacher} />;
  }

  if (activeTab === 'dashboard') {
    return (
      <div className="space-y-6">
        <div>
          <h2 className="text-2xl font-semibold">Teacher Dashboard</h2>
          <p className="text-muted-foreground">Manage your classes and track student attendance.</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Today's Classes</CardTitle>
              <CalendarIcon className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{todayClasses.length}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Students</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">93</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Avg Attendance</CardTitle>
              <BarChart3 className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">88%</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Classes This Week</CardTitle>
              <FileText className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">15</div>
            </CardContent>
          </Card>
        </div>

        {/* Today's Classes */}
        <Card>
          <CardHeader>
            <CardTitle>Today's Classes</CardTitle>
            <CardDescription>Your scheduled classes for today</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {todayClasses.map((class_) => (
                <div key={class_.id} className="flex items-center justify-between p-4 border rounded-lg">
                  <div>
                    <h4 className="font-medium">{class_.subject}</h4>
                    <p className="text-sm text-muted-foreground">{class_.time} • {class_.room}</p>
                    <p className="text-sm text-muted-foreground">
                      {class_.attended}/{class_.students} students attended
                    </p>
                  </div>
                  <div className="flex items-center space-x-2">
                    {class_.attended > 0 ? (
                      <Badge variant="default">In Session</Badge>
                    ) : (
                      <Badge variant="secondary">Upcoming</Badge>
                    )}
                    <Button
                      size="sm"
                      onClick={() => generateQRCode(class_.id)}
                      disabled={class_.attended > 0}
                    >
                      <QrCode className="w-4 h-4 mr-2" />
                      Start Attendance
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (activeTab === 'attendance') {
    return (
      <div className="space-y-6">
        <div>
          <h2 className="text-2xl font-semibold">Take Attendance</h2>
          <p className="text-muted-foreground">Start attendance session and monitor student check-ins</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* QR Code Generation */}
          <Card>
            <CardHeader>
              <CardTitle>Generate QR Code</CardTitle>
              <CardDescription>Create a QR code for students to scan</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Select Class</Label>
                <Select value={selectedClass} onValueChange={setSelectedClass}>
                  <SelectTrigger>
                    <SelectValue placeholder="Choose a class" />
                  </SelectTrigger>
                  <SelectContent>
                    {todayClasses.map((class_) => (
                      <SelectItem key={class_.id} value={class_.id.toString()}>
                        {class_.subject} - {class_.time}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {showQRCode ? (
                <div className="text-center">
                  <div className="w-48 h-48 mx-auto bg-white border-2 border-gray-300 rounded-lg flex items-center justify-center mb-4">
                    <div className="grid grid-cols-8 gap-1">
                      {Array.from({ length: 64 }).map((_, i) => (
                        <div
                          key={i}
                          className={`w-2 h-2 ${Math.random() > 0.5 ? 'bg-black' : 'bg-white'}`}
                        />
                      ))}
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground">Session Code: ATT-{Date.now().toString().slice(-6)}</p>
                  <Button variant="outline" onClick={() => setShowQRCode(false)} className="mt-2">
                    End Session
                  </Button>
                </div>
              ) : (
                <Button 
                  onClick={() => setShowQRCode(true)} 
                  disabled={!selectedClass}
                  className="w-full"
                >
                  <QrCode className="w-4 h-4 mr-2" />
                  Generate QR Code
                </Button>
              )}
            </CardContent>
          </Card>

          {/* Live Attendance */}
          <Card>
            <CardHeader>
              <CardTitle>Live Attendance</CardTitle>
              <CardDescription>Students who have marked attendance</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {students.map((student) => (
                  <div key={student.id} className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <h4 className="font-medium">{student.name}</h4>
                      <p className="text-sm text-muted-foreground">{student.id}</p>
                    </div>
                    <div className="flex items-center space-x-2">
                      {student.status === 'present' && (
                        <CheckCircle className="w-5 h-5 text-green-500" />
                      )}
                      {student.status === 'absent' && (
                        <XCircle className="w-5 h-5 text-red-500" />
                      )}
                      {student.status === 'late' && (
                        <Clock className="w-5 h-5 text-orange-500" />
                      )}
                      <Badge
                        variant={
                          student.status === 'present' ? 'default' :
                          student.status === 'late' ? 'secondary' : 'destructive'
                        }
                      >
                        {student.status}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (activeTab === 'schedule') {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-semibold">Schedule Class</h2>
            <p className="text-muted-foreground">Create and manage class schedules</p>
          </div>
          <Dialog>
            <DialogTrigger asChild>
              <Button>
                <Plus className="w-4 h-4 mr-2" />
                New Class
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px]">
              <DialogHeader>
                <DialogTitle>Schedule New Class</DialogTitle>
                <DialogDescription>
                  Add a new class session to your schedule.
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="space-y-2">
                  <Label>Subject</Label>
                  <Input placeholder="Enter subject name" />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Date</Label>
                    <Input type="date" />
                  </div>
                  <div className="space-y-2">
                    <Label>Time</Label>
                    <Input type="time" />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Room</Label>
                  <Input placeholder="Room number or location" />
                </div>
                <div className="space-y-2">
                  <Label>Description</Label>
                  <Textarea placeholder="Class description or agenda" />
                </div>
              </div>
              <div className="flex justify-end space-x-2">
                <Button variant="outline">Cancel</Button>
                <Button>Schedule Class</Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Calendar</CardTitle>
            </CardHeader>
            <CardContent>
              <Calendar
                mode="single"
                selected={selectedDate}
                onSelect={setSelectedDate}
                className="rounded-md border"
              />
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Upcoming Classes</CardTitle>
              <CardDescription>Your scheduled classes</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {todayClasses.map((class_) => (
                <div key={class_.id} className="p-3 border rounded-lg">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium">{class_.subject}</h4>
                      <p className="text-sm text-muted-foreground">{class_.time} • {class_.room}</p>
                    </div>
                    <Button variant="outline" size="sm">Edit</Button>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (activeTab === 'reports') {
    return (
      <div className="space-y-6">
        <div>
          <h2 className="text-2xl font-semibold">Class Reports</h2>
          <p className="text-muted-foreground">View attendance and performance analytics</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Class Performance Summary</CardTitle>
            <CardDescription>Attendance statistics for your classes</CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Subject</TableHead>
                  <TableHead>Total Classes</TableHead>
                  <TableHead>Average Attendance</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {classReports.map((report) => (
                  <TableRow key={report.subject}>
                    <TableCell className="font-medium">{report.subject}</TableCell>
                    <TableCell>{report.totalClasses}</TableCell>
                    <TableCell>{report.avgAttendance}%</TableCell>
                    <TableCell>
                      <Badge variant={report.avgAttendance >= 90 ? 'default' : 'secondary'}>
                        {report.avgAttendance >= 90 ? 'Excellent' : 'Good'}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    );
  }



  if (activeTab === 'resources') {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-semibold">Resources</h2>
            <p className="text-muted-foreground">Upload and manage class materials</p>
          </div>
          <Button>
            <Upload className="w-4 h-4 mr-2" />
            Upload Resource
          </Button>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Class Materials</CardTitle>
            <CardDescription>Uploaded notes, assignments, and resources</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {['Mathematics Notes - Chapter 5', 'Physics Lab Manual', 'Chemistry Assignment 3'].map((resource, index) => (
                <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center space-x-3">
                    <FileText className="w-5 h-5 text-muted-foreground" />
                    <div>
                      <h4 className="font-medium">{resource}</h4>
                      <p className="text-sm text-muted-foreground">Uploaded 2 days ago</p>
                    </div>
                  </div>
                  <Button variant="outline" size="sm">Download</Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return null;
}