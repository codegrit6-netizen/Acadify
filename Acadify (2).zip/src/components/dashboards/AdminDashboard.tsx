import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../ui/table';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { AnnouncementManagement } from '../announcements/AnnouncementManagement';
import { getUserById } from '../../data/mockDatabase';
import type { Admin } from '../../data/mockDatabase';
import { 
  Users, 
  GraduationCap, 
  Calendar, 
  BarChart3, 
  Plus,
  Edit,
  Trash2,
  UserPlus,
  Settings,
  TrendingUp,
  Activity
} from 'lucide-react';

interface AdminDashboardProps {
  activeTab: string;
  adminId: string;
}

export function AdminDashboard({ activeTab, adminId }: AdminDashboardProps) {
  const [selectedUserType, setSelectedUserType] = useState('all');
  
  // Get admin data from database
  const admin = getUserById(adminId, 'admin') as Admin;

  // Mock data
  const systemStats = {
    totalStudents: 1250,
    totalTeachers: 85,
    totalClasses: 45,
    avgAttendance: 87,
    activeActivities: 12,
    pendingReports: 8
  };

  const users = [
    { id: 'STU001', name: 'John Doe', type: 'Student', email: 'john@example.com', status: 'Active', lastLogin: '2 hours ago' },
    { id: 'TCH001', name: 'Prof. Smith', type: 'Teacher', email: 'smith@example.com', status: 'Active', lastLogin: '1 hour ago' },
    { id: 'STU002', name: 'Jane Wilson', type: 'Student', email: 'jane@example.com', status: 'Inactive', lastLogin: '3 days ago' },
    { id: 'PAR001', name: 'Mr. Johnson', type: 'Parent', email: 'johnson@example.com', status: 'Active', lastLogin: '1 day ago' },
    { id: 'TCH002', name: 'Dr. Brown', type: 'Teacher', email: 'brown@example.com', status: 'Active', lastLogin: '30 min ago' },
  ];

  const attendanceReports = [
    { class: 'Mathematics Grade 10', teacher: 'Prof. Smith', students: 35, avgAttendance: 92, trend: 'up' },
    { class: 'Physics Grade 11', teacher: 'Dr. Brown', students: 30, avgAttendance: 88, trend: 'down' },
    { class: 'Chemistry Grade 12', teacher: 'Prof. Davis', students: 28, avgAttendance: 95, trend: 'up' },
    { class: 'Biology Grade 10', teacher: 'Dr. Wilson', students: 32, avgAttendance: 85, trend: 'stable' },
  ];

  const activities = [
    { id: 1, title: 'Science Fair 2025', date: '2025-09-15', type: 'Event', status: 'Upcoming', participants: 150 },
    { id: 2, title: 'Math Olympiad', date: '2025-09-22', type: 'Competition', status: 'Registration Open', participants: 80 },
    { id: 3, title: 'Annual Sports Day', date: '2025-10-05', type: 'Sports', status: 'Planning', participants: 500 },
    { id: 4, title: 'Cultural Festival', date: '2025-10-15', type: 'Cultural', status: 'Upcoming', participants: 300 },
  ];

  const filteredUsers = selectedUserType === 'all' 
    ? users 
    : users.filter(user => user.type.toLowerCase() === selectedUserType);

  if (!admin) {
    return <div>Admin not found</div>;
  }

  if (activeTab === 'announcements') {
    return <AnnouncementManagement user={admin} />;
  }

  if (activeTab === 'dashboard') {
    return (
      <div className="space-y-6">
        <div>
          <h2 className="text-2xl font-semibold">Admin Dashboard</h2>
          <p className="text-muted-foreground">System overview and management console</p>
        </div>

        {/* System Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Students</CardTitle>
              <GraduationCap className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{systemStats.totalStudents.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">+5% from last month</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Teachers</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{systemStats.totalTeachers}</div>
              <p className="text-xs text-muted-foreground">+2 new this month</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Classes</CardTitle>
              <Calendar className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{systemStats.totalClasses}</div>
              <p className="text-xs text-muted-foreground">Active sessions</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Avg Attendance</CardTitle>
              <BarChart3 className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{systemStats.avgAttendance}%</div>
              <p className="text-xs text-muted-foreground">+3% this week</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Activities</CardTitle>
              <Activity className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{systemStats.activeActivities}</div>
              <p className="text-xs text-muted-foreground">This month</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Reports</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{systemStats.pendingReports}</div>
              <p className="text-xs text-muted-foreground">Pending review</p>
            </CardContent>
          </Card>
        </div>

        {/* Recent Activity & Top Performing Classes */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Top Performing Classes</CardTitle>
              <CardDescription>Classes with highest attendance rates</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {attendanceReports
                .sort((a, b) => b.avgAttendance - a.avgAttendance)
                .slice(0, 3)
                .map((report, index) => (
                <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                  <div>
                    <h4 className="font-medium">{report.class}</h4>
                    <p className="text-sm text-muted-foreground">{report.teacher}</p>
                  </div>
                  <div className="text-right">
                    <div className="font-medium">{report.avgAttendance}%</div>
                    <Badge variant="default" className="text-xs">
                      #{index + 1}
                    </Badge>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Upcoming Activities</CardTitle>
              <CardDescription>Events and activities scheduled</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {activities.slice(0, 3).map((activity) => (
                <div key={activity.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div>
                    <h4 className="font-medium">{activity.title}</h4>
                    <p className="text-sm text-muted-foreground">{activity.date} • {activity.participants} participants</p>
                  </div>
                  <Badge variant="outline">{activity.status}</Badge>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (activeTab === 'users') {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-semibold">User Management</h2>
            <p className="text-muted-foreground">Manage students, teachers, and parents</p>
          </div>
          <Dialog>
            <DialogTrigger asChild>
              <Button>
                <UserPlus className="w-4 h-4 mr-2" />
                Add User
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px]">
              <DialogHeader>
                <DialogTitle>Add New User</DialogTitle>
                <DialogDescription>Create a new user account in the system.</DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="space-y-2">
                  <Label>User Type</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select user type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="student">Student</SelectItem>
                      <SelectItem value="teacher">Teacher</SelectItem>
                      <SelectItem value="parent">Parent</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Full Name</Label>
                  <Input placeholder="Enter full name" />
                </div>
                <div className="space-y-2">
                  <Label>Email</Label>
                  <Input type="email" placeholder="Enter email address" />
                </div>
                <div className="space-y-2">
                  <Label>User ID</Label>
                  <Input placeholder="Auto-generated or custom ID" />
                </div>
              </div>
              <div className="flex justify-end space-x-2">
                <Button variant="outline">Cancel</Button>
                <Button>Create User</Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Filter Controls */}
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <Label>Filter by type:</Label>
            <Select value={selectedUserType} onValueChange={setSelectedUserType}>
              <SelectTrigger className="w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Users</SelectItem>
                <SelectItem value="student">Students</SelectItem>
                <SelectItem value="teacher">Teachers</SelectItem>
                <SelectItem value="parent">Parents</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Input placeholder="Search users..." className="max-w-sm" />
        </div>

        {/* Users Table */}
        <Card>
          <CardHeader>
            <CardTitle>System Users</CardTitle>
            <CardDescription>Manage all registered users in the system</CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>User ID</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Last Login</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredUsers.map((user) => (
                  <TableRow key={user.id}>
                    <TableCell className="font-medium">{user.id}</TableCell>
                    <TableCell>{user.name}</TableCell>
                    <TableCell>
                      <Badge variant="outline">{user.type}</Badge>
                    </TableCell>
                    <TableCell>{user.email}</TableCell>
                    <TableCell>
                      <Badge variant={user.status === 'Active' ? 'default' : 'secondary'}>
                        {user.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-muted-foreground">{user.lastLogin}</TableCell>
                    <TableCell>
                      <div className="flex items-center space-x-2">
                        <Button variant="ghost" size="sm">
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="sm">
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (activeTab === 'reports') {
    return (
      <div className="space-y-6">
        <div>
          <h2 className="text-2xl font-semibold">System Reports</h2>
          <p className="text-muted-foreground">Comprehensive analytics and reporting</p>
        </div>

        <Tabs defaultValue="attendance" className="w-full">
          <TabsList>
            <TabsTrigger value="attendance">Attendance Reports</TabsTrigger>
            <TabsTrigger value="performance">Performance Analytics</TabsTrigger>
            <TabsTrigger value="activities">Activity Reports</TabsTrigger>
          </TabsList>

          <TabsContent value="attendance" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Class Attendance Overview</CardTitle>
                <CardDescription>Attendance statistics by class and teacher</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Class</TableHead>
                      <TableHead>Teacher</TableHead>
                      <TableHead>Students</TableHead>
                      <TableHead>Avg Attendance</TableHead>
                      <TableHead>Trend</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {attendanceReports.map((report, index) => (
                      <TableRow key={index}>
                        <TableCell className="font-medium">{report.class}</TableCell>
                        <TableCell>{report.teacher}</TableCell>
                        <TableCell>{report.students}</TableCell>
                        <TableCell>{report.avgAttendance}%</TableCell>
                        <TableCell>
                          <div className="flex items-center space-x-1">
                            <TrendingUp 
                              className={`w-4 h-4 ${
                                report.trend === 'up' ? 'text-green-500' : 
                                report.trend === 'down' ? 'text-red-500' : 'text-gray-500'
                              }`} 
                            />
                            <span className="capitalize text-sm">{report.trend}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Button variant="outline" size="sm">View Details</Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="performance" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Overall Attendance</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">87%</div>
                  <p className="text-xs text-muted-foreground">+2% from last month</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Top Performing Class</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-lg font-bold">Chemistry Grade 12</div>
                  <p className="text-xs text-muted-foreground">95% attendance</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Improvement Needed</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-lg font-bold">Biology Grade 10</div>
                  <p className="text-xs text-muted-foreground">85% attendance</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Active Teachers</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">85</div>
                  <p className="text-xs text-muted-foreground">All actively teaching</p>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="activities" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Activity Participation</CardTitle>
                <CardDescription>Student engagement in extracurricular activities</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Activity</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Participants</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {activities.map((activity) => (
                      <TableRow key={activity.id}>
                        <TableCell className="font-medium">{activity.title}</TableCell>
                        <TableCell>{activity.date}</TableCell>
                        <TableCell>
                          <Badge variant="outline">{activity.type}</Badge>
                        </TableCell>
                        <TableCell>{activity.participants}</TableCell>
                        <TableCell>
                          <Badge 
                            variant={
                              activity.status === 'Upcoming' ? 'default' : 'secondary'
                            }
                          >
                            {activity.status}
                          </Badge>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    );
  }

  if (activeTab === 'activities') {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-semibold">Activities Management</h2>
            <p className="text-muted-foreground">Manage school events and activities</p>
          </div>
          <Button>
            <Plus className="w-4 h-4 mr-2" />
            New Activity
          </Button>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>All Activities</CardTitle>
            <CardDescription>Manage and monitor school activities</CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Activity</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Participants</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {activities.map((activity) => (
                  <TableRow key={activity.id}>
                    <TableCell className="font-medium">{activity.title}</TableCell>
                    <TableCell>{activity.date}</TableCell>
                    <TableCell>
                      <Badge variant="outline">{activity.type}</Badge>
                    </TableCell>
                    <TableCell>{activity.participants}</TableCell>
                    <TableCell>
                      <Badge 
                        variant={
                          activity.status === 'Upcoming' ? 'default' : 'secondary'
                        }
                      >
                        {activity.status}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center space-x-2">
                        <Button variant="ghost" size="sm">
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="sm">
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    );
  }



  if (activeTab === 'settings') {
    return (
      <div className="space-y-6">
        <div>
          <h2 className="text-2xl font-semibold">System Settings</h2>
          <p className="text-muted-foreground">Configure system preferences and security</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>General Settings</CardTitle>
              <CardDescription>Basic system configuration</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>School Name</Label>
                <Input defaultValue="Smart Academy" />
              </div>
              <div className="space-y-2">
                <Label>Academic Year</Label>
                <Select defaultValue="2024-2025">
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="2024-2025">2024-2025</SelectItem>
                    <SelectItem value="2025-2026">2025-2026</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Timezone</Label>
                <Select defaultValue="UTC+5:30">
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="UTC+5:30">UTC+5:30 (IST)</SelectItem>
                    <SelectItem value="UTC+0">UTC+0 (GMT)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button>Save Changes</Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Attendance Settings</CardTitle>
              <CardDescription>Configure attendance tracking preferences</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Attendance Window (minutes)</Label>
                <Input type="number" defaultValue="15" />
              </div>
              <div className="space-y-2">
                <Label>Late Threshold (minutes)</Label>
                <Input type="number" defaultValue="10" />
              </div>
              <div className="space-y-2">
                <Label>Auto-close Session</Label>
                <Select defaultValue="60">
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="30">30 minutes</SelectItem>
                    <SelectItem value="60">60 minutes</SelectItem>
                    <SelectItem value="120">120 minutes</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button>Save Settings</Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return null;
}