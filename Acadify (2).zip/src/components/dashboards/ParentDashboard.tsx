import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Progress } from '../ui/progress';
import { Calendar } from '../ui/calendar';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../ui/table';
import { AnnouncementsView } from '../announcements/AnnouncementsView';
import { 
  User, 
  Calendar as CalendarIcon, 
  TrendingUp, 
  CheckCircle, 
  XCircle, 
  Clock,
  BookOpen,
  Award,
  Bell
} from 'lucide-react';

interface ParentDashboardProps {
  activeTab: string;
  parentId: string;
}

export function ParentDashboard({ activeTab, parentId }: ParentDashboardProps) {
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());
  const [selectedChild, setSelectedChild] = useState('child1');

  // Mock data
  const children = [
    { id: 'child1', name: 'Emma Johnson', grade: 'Grade 10', rollNo: 'STU001' },
    { id: 'child2', name: 'Alex Johnson', grade: 'Grade 8', rollNo: 'STU002' }
  ];

  const attendanceData = {
    child1: {
      overall: 88,
      monthly: 92,
      subjects: [
        { name: 'Mathematics', attendance: 90, classes: 20 },
        { name: 'Physics', attendance: 85, classes: 18 },
        { name: 'Chemistry', attendance: 92, classes: 19 },
        { name: 'English', attendance: 88, classes: 16 },
      ]
    },
    child2: {
      overall: 95,
      monthly: 98,
      subjects: [
        { name: 'Mathematics', attendance: 96, classes: 18 },
        { name: 'Science', attendance: 94, classes: 16 },
        { name: 'English', attendance: 95, classes: 15 },
        { name: 'Social Studies', attendance: 97, classes: 14 },
      ]
    }
  };

  const recentActivities = [
    { date: '2025-09-02', activity: 'Mathematics Class', status: 'present', time: '09:05 AM' },
    { date: '2025-09-02', activity: 'Physics Lab', status: 'present', time: '11:03 AM' },
    { date: '2025-09-01', activity: 'Chemistry Class', status: 'present', time: '02:07 PM' },
    { date: '2025-09-01', activity: 'English Literature', status: 'absent', time: '-' },
    { date: '2025-08-31', activity: 'Mathematics Quiz', status: 'present', time: '09:02 AM' },
  ];

  const upcomingEvents = [
    { date: '2025-09-05', title: 'Parent-Teacher Meeting', type: 'Meeting', time: '10:00 AM' },
    { date: '2025-09-10', title: 'Science Fair Participation', type: 'Event', time: '02:00 PM' },
    { date: '2025-09-15', title: 'Monthly Assessment', type: 'Exam', time: '09:00 AM' },
    { date: '2025-09-20', title: 'Sports Day', type: 'Sports', time: '08:00 AM' },
  ];

  const notifications = [
    { id: 1, message: 'Emma missed Chemistry class today', type: 'attendance', time: '2 hours ago', urgent: true },
    { id: 2, message: 'Parent-Teacher meeting scheduled for Sept 5', type: 'event', time: '1 day ago', urgent: false },
    { id: 3, message: 'Alex scored 95% in Math quiz', type: 'achievement', time: '2 days ago', urgent: false },
    { id: 4, message: 'Science Fair permission slip required', type: 'action', time: '3 days ago', urgent: true },
  ];

  const currentChild = children.find(child => child.id === selectedChild) || children[0];
  const currentAttendance = attendanceData[selectedChild as keyof typeof attendanceData];

  if (activeTab === 'announcements') {
    return <AnnouncementsView userId={parentId} userType="parent" />;
  }

  if (activeTab === 'dashboard') {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-semibold">Parent Dashboard</h2>
            <p className="text-muted-foreground">Monitor your child's academic progress and attendance</p>
          </div>
          <Select value={selectedChild} onValueChange={setSelectedChild}>
            <SelectTrigger className="w-48">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {children.map((child) => (
                <SelectItem key={child.id} value={child.id}>
                  {child.name} ({child.grade})
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Child Overview */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <User className="w-5 h-5" />
              <span>{currentChild.name}</span>
            </CardTitle>
            <CardDescription>
              {currentChild.grade} • Roll No: {currentChild.rollNo}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-primary">{currentAttendance.overall}%</div>
                <p className="text-sm text-muted-foreground">Overall Attendance</p>
                <Progress value={currentAttendance.overall} className="mt-2" />
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-green-600">{currentAttendance.monthly}%</div>
                <p className="text-sm text-muted-foreground">This Month</p>
                <Progress value={currentAttendance.monthly} className="mt-2" />
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-600">4</div>
                <p className="text-sm text-muted-foreground">Subjects Enrolled</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Quick Stats & Notifications */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Subject-wise Attendance</CardTitle>
              <CardDescription>Attendance breakdown by subject</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {currentAttendance.subjects.map((subject) => (
                <div key={subject.name} className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium">{subject.name}</h4>
                    <p className="text-sm text-muted-foreground">{subject.classes} classes</p>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Progress value={subject.attendance} className="w-20" />
                    <span className="text-sm font-medium">{subject.attendance}%</span>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Recent Notifications</CardTitle>
              <CardDescription>Important updates about your child</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {notifications.slice(0, 4).map((notification) => (
                <div key={notification.id} className="flex items-start space-x-3 p-3 border rounded-lg">
                  <div className={`p-1 rounded-full ${
                    notification.urgent ? 'bg-red-100' : 'bg-blue-100'
                  }`}>
                    <Bell className={`w-3 h-3 ${
                      notification.urgent ? 'text-red-600' : 'text-blue-600'
                    }`} />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm">{notification.message}</p>
                    <p className="text-xs text-muted-foreground">{notification.time}</p>
                  </div>
                  {notification.urgent && (
                    <Badge variant="destructive" className="text-xs">Urgent</Badge>
                  )}
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (activeTab === 'attendance') {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-semibold">Child Attendance</h2>
            <p className="text-muted-foreground">Detailed attendance tracking for your child</p>
          </div>
          <Select value={selectedChild} onValueChange={setSelectedChild}>
            <SelectTrigger className="w-48">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {children.map((child) => (
                <SelectItem key={child.id} value={child.id}>
                  {child.name} ({child.grade})
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Attendance Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Overall Attendance</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{currentAttendance.overall}%</div>
              <p className="text-xs text-muted-foreground">This academic year</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">This Month</CardTitle>
              <CalendarIcon className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{currentAttendance.monthly}%</div>
              <p className="text-xs text-muted-foreground">September 2025</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Classes Attended</CardTitle>
              <CheckCircle className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">67</div>
              <p className="text-xs text-muted-foreground">Out of 76 classes</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Absences</CardTitle>
              <XCircle className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">9</div>
              <p className="text-xs text-muted-foreground">Classes missed</p>
            </CardContent>
          </Card>
        </div>

        {/* Recent Attendance & Subject Breakdown */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Recent Attendance</CardTitle>
              <CardDescription>Last 5 attendance records</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {recentActivities.map((activity, index) => (
                  <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <h4 className="font-medium">{activity.activity}</h4>
                      <p className="text-sm text-muted-foreground">{activity.date}</p>
                    </div>
                    <div className="flex items-center space-x-2">
                      {activity.status === 'present' ? (
                        <CheckCircle className="w-5 h-5 text-green-500" />
                      ) : activity.status === 'late' ? (
                        <Clock className="w-5 h-5 text-orange-500" />
                      ) : (
                        <XCircle className="w-5 h-5 text-red-500" />
                      )}
                      <div className="text-right">
                        <Badge
                          variant={
                            activity.status === 'present' ? 'default' :
                            activity.status === 'late' ? 'secondary' : 'destructive'
                          }
                        >
                          {activity.status}
                        </Badge>
                        {activity.time !== '-' && (
                          <p className="text-xs text-muted-foreground mt-1">{activity.time}</p>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Subject Performance</CardTitle>
              <CardDescription>Attendance percentage by subject</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Subject</TableHead>
                    <TableHead>Classes</TableHead>
                    <TableHead>Attendance</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {currentAttendance.subjects.map((subject) => (
                    <TableRow key={subject.name}>
                      <TableCell className="font-medium">{subject.name}</TableCell>
                      <TableCell>{subject.classes}</TableCell>
                      <TableCell>
                        <div className="flex items-center space-x-2">
                          <Progress value={subject.attendance} className="w-16" />
                          <span className="text-sm">{subject.attendance}%</span>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (activeTab === 'activities') {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-semibold">Activities & Events</h2>
            <p className="text-muted-foreground">Upcoming events and activities for your child</p>
          </div>
          <Select value={selectedChild} onValueChange={setSelectedChild}>
            <SelectTrigger className="w-48">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {children.map((child) => (
                <SelectItem key={child.id} value={child.id}>
                  {child.name} ({child.grade})
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Calendar</CardTitle>
              <CardDescription>Select a date to view activities</CardDescription>
            </CardHeader>
            <CardContent>
              <Calendar
                mode="single"
                selected={selectedDate}
                onSelect={setSelectedDate}
                className="rounded-md border"
              />
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Upcoming Events</CardTitle>
              <CardDescription>Events and activities scheduled</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {upcomingEvents.map((event, index) => (
                <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                  <div>
                    <h4 className="font-medium">{event.title}</h4>
                    <p className="text-sm text-muted-foreground">{event.date} • {event.time}</p>
                  </div>
                  <Badge variant="outline">{event.type}</Badge>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (activeTab === 'progress') {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-semibold">Academic Progress</h2>
            <p className="text-muted-foreground">Track your child's academic performance and achievements</p>
          </div>
          <Select value={selectedChild} onValueChange={setSelectedChild}>
            <SelectTrigger className="w-48">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {children.map((child) => (
                <SelectItem key={child.id} value={child.id}>
                  {child.name} ({child.grade})
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Progress Overview */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Overall Grade</CardTitle>
              <Award className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">A-</div>
              <p className="text-xs text-muted-foreground">Above average performance</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Assignments</CardTitle>
              <BookOpen className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">12/15</div>
              <p className="text-xs text-muted-foreground">Completed this month</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Participation</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">Excellent</div>
              <p className="text-xs text-muted-foreground">Active in class activities</p>
            </CardContent>
          </Card>
        </div>

        {/* Subject Performance & Recent Achievements */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Subject Performance</CardTitle>
              <CardDescription>Grades and performance by subject</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {currentAttendance.subjects.map((subject) => (
                  <div key={subject.name} className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <h4 className="font-medium">{subject.name}</h4>
                      <p className="text-sm text-muted-foreground">{subject.attendance}% attendance</p>
                    </div>
                    <div className="text-right">
                      <div className="text-lg font-medium">
                        {subject.name === 'Mathematics' ? 'A' :
                         subject.name === 'Physics' ? 'B+' :
                         subject.name === 'Chemistry' ? 'A-' : 'A'}
                      </div>
                      <Badge variant="outline" className="text-xs">
                        {subject.attendance >= 90 ? 'Excellent' : 'Good'}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Recent Achievements</CardTitle>
              <CardDescription>Awards and recognitions</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {[
                { title: 'Perfect Attendance - August', date: '2025-08-31', type: 'Attendance' },
                { title: 'Math Quiz - First Place', date: '2025-08-28', type: 'Academic' },
                { title: 'Science Project Excellence', date: '2025-08-25', type: 'Project' },
                { title: 'Class Representative', date: '2025-08-15', type: 'Leadership' }
              ].map((achievement, index) => (
                <div key={index} className="flex items-center space-x-3 p-3 border rounded-lg">
                  <div className="w-10 h-10 bg-yellow-100 rounded-full flex items-center justify-center">
                    <Award className="w-5 h-5 text-yellow-600" />
                  </div>
                  <div className="flex-1">
                    <h4 className="font-medium">{achievement.title}</h4>
                    <p className="text-sm text-muted-foreground">{achievement.date}</p>
                  </div>
                  <Badge variant="outline">{achievement.type}</Badge>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return null;
}