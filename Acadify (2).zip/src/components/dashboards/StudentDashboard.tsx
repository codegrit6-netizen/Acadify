import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Progress } from '../ui/progress';
import { Calendar } from '../ui/calendar';
import { FreePeriodActivities } from '../activities/FreePeriodActivities';
import { AnnouncementsView } from '../announcements/AnnouncementsView';
import { PerformanceCertificate } from '../certificates/PerformanceCertificate';
import { AIStudentChatbot } from '../ai/AIStudentChatbot';
import { getUserById, getStudentParent } from '../../data/mockDatabase';
import type { Student } from '../../data/mockDatabase';
import { 
  QrCode, 
  Calendar as CalendarIcon, 
  CheckCircle, 
  Clock, 
  BookOpen,
  TrendingUp,
  Bell,
  User,
  Mail,
  Phone,
  MapPin,
  GraduationCap,
  Users
} from 'lucide-react';

interface StudentDashboardProps {
  activeTab: string;
  studentId: string;
}

export function StudentDashboard({ activeTab, studentId }: StudentDashboardProps) {
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());
  const [isScanning, setIsScanning] = useState(false);

  // Get student data from database
  const student = getUserById(studentId, 'student') as Student;
  const parent = student ? getStudentParent(studentId) : null;

  if (!student) {
    return <div>Student not found</div>;
  }

  const attendanceStats = student.attendanceStats;

  // Today's classes based on student's subjects
  const todayClasses = student.subjects.map((subject, index) => ({
    id: index + 1,
    subject,
    time: ['09:00 AM', '11:00 AM', '02:00 PM', '03:00 PM', '04:00 PM'][index] || '09:00 AM',
    room: `Room ${101 + index}`,
    status: index < 2 ? 'present' : 'pending'
  }));

  const upcomingActivities = [
    { id: 1, title: 'Tech Symposium', date: '2024-09-15', type: 'Event' },
    { id: 2, title: `${student.subjects[0]} Assignment`, date: '2024-09-12', type: 'Assessment' },
    { id: 3, title: 'Lab Practical', date: '2024-09-18', type: 'Practical' },
  ];

  const notifications = [
    { id: 1, message: `New assignment uploaded for ${student.subjects[0]}`, time: '2 hours ago' },
    { id: 2, message: `${student.subjects[1]} lab session rescheduled`, time: '1 day ago' },
    { id: 3, message: 'Parent-teacher meeting scheduled', time: '2 days ago' },
  ];

  const handleQRScan = () => {
    setIsScanning(true);
    // Simulate QR scanning
    setTimeout(() => {
      setIsScanning(false);
      // Update attendance status
      alert('Attendance marked successfully!');
    }, 2000);
  };

  if (activeTab === 'dashboard') {
    return (
      <div className="space-y-6">
        <div>
          <h2 className="text-2xl font-semibold">Welcome back, {student.name}!</h2>
          <p className="text-muted-foreground">Here's your academic overview for today.</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="professional-card hover:shadow-md">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-foreground">Attendance Rate</CardTitle>
              <div className="w-10 h-10 bg-success rounded-lg flex items-center justify-center">
                <TrendingUp className="h-5 w-5 text-success-foreground" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-primary">{attendanceStats.percentage}%</div>
              <Progress value={attendanceStats.percentage} className="mt-2" />
              <p className="text-xs text-muted-foreground mt-2">
                {attendanceStats.present}/{attendanceStats.total} classes attended
              </p>
            </CardContent>
          </Card>

          <Card className="professional-card hover:shadow-md">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-foreground">Today's Classes</CardTitle>
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                <BookOpen className="h-5 w-5 text-primary-foreground" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-primary">{todayClasses.length}</div>
              <p className="text-xs text-muted-foreground">
                {todayClasses.filter(c => c.status === 'present').length} attended
              </p>
            </CardContent>
          </Card>

          <Card className="professional-card hover:shadow-md">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-foreground">Upcoming Events</CardTitle>
              <div className="w-10 h-10 bg-accent rounded-lg flex items-center justify-center">
                <CalendarIcon className="h-5 w-5 text-accent-foreground" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-primary">{upcomingActivities.length}</div>
              <p className="text-xs text-muted-foreground">This week</p>
            </CardContent>
          </Card>
        </div>

        {/* Today's Schedule & Notifications */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card className="professional-card">
            <CardHeader>
              <CardTitle className="text-primary">Today's Schedule</CardTitle>
              <CardDescription>Your classes for today</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {todayClasses.map((class_) => (
                <div key={class_.id} className="flex items-center justify-between p-3 border border-border rounded-lg bg-secondary/30">
                  <div>
                    <h4 className="font-medium text-foreground">{class_.subject}</h4>
                    <p className="text-sm text-muted-foreground">{class_.time} • {class_.room}</p>
                  </div>
                  <div className={`status-indicator ${
                    class_.status === 'present' ? 'status-present' : 'status-pending'
                  }`}>
                    {class_.status === 'present' ? 'Present' : 'Pending'}
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card className="professional-card">
            <CardHeader>
              <CardTitle className="text-primary">Recent Notifications</CardTitle>
              <CardDescription>Latest updates and announcements</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {notifications.map((notification) => (
                <div key={notification.id} className="flex items-start space-x-3 p-3 border border-border rounded-lg bg-muted/20">
                  <Bell className="w-4 h-4 text-accent mt-1 flex-shrink-0" />
                  <div className="flex-1">
                    <p className="text-sm text-foreground">{notification.message}</p>
                    <p className="text-xs text-muted-foreground">{notification.time}</p>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (activeTab === 'attendance') {
    return (
      <div className="space-y-6">
        <div>
          <h2 className="text-2xl font-semibold">Mark Attendance</h2>
          <p className="text-muted-foreground">Scan QR code to mark your attendance</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>QR Code Scanner</CardTitle>
              <CardDescription>Point your camera at the QR code displayed by your teacher</CardDescription>
            </CardHeader>
            <CardContent className="text-center">
              <div className="w-64 h-64 mx-auto border-2 border-dashed border-muted-foreground rounded-lg flex items-center justify-center mb-4">
                {isScanning ? (
                  <div className="text-center">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-2"></div>
                    <p className="text-sm text-muted-foreground">Scanning...</p>
                  </div>
                ) : (
                  <div className="text-center">
                    <QrCode className="w-16 h-16 text-muted-foreground mx-auto mb-2" />
                    <p className="text-sm text-muted-foreground">Position QR code in frame</p>
                  </div>
                )}
              </div>
              <Button 
                onClick={handleQRScan} 
                disabled={isScanning} 
                className="w-full btn-accent"
              >
                {isScanning ? 'Scanning...' : 'Start Camera'}
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Today's Attendance Status</CardTitle>
              <CardDescription>Your attendance for today's classes</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {todayClasses.map((class_) => (
                <div key={class_.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div>
                    <h4 className="font-medium">{class_.subject}</h4>
                    <p className="text-sm text-muted-foreground">{class_.time}</p>
                  </div>
                  <div className="flex items-center space-x-2">
                    {class_.status === 'present' ? (
                      <CheckCircle className="w-5 h-5 text-green-500" />
                    ) : (
                      <Clock className="w-5 h-5 text-orange-500" />
                    )}
                    <Badge variant={class_.status === 'present' ? 'default' : 'secondary'}>
                      {class_.status === 'present' ? 'Present' : 'Pending'}
                    </Badge>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (activeTab === 'calendar') {
    return (
      <div className="space-y-6">
        <div>
          <h2 className="text-2xl font-semibold">Activity Calendar</h2>
          <p className="text-muted-foreground">View your upcoming activities and events</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Calendar</CardTitle>
            </CardHeader>
            <CardContent>
              <Calendar
                mode="single"
                selected={selectedDate}
                onSelect={setSelectedDate}
                className="rounded-md border"
              />
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Upcoming Activities</CardTitle>
              <CardDescription>Events and activities scheduled for this month</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {upcomingActivities.map((activity) => (
                <div key={activity.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div>
                    <h4 className="font-medium">{activity.title}</h4>
                    <p className="text-sm text-muted-foreground">{activity.date}</p>
                  </div>
                  <Badge variant="outline">{activity.type}</Badge>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (activeTab === 'announcements') {
    return <AnnouncementsView userId={student.id} userType="student" userClass={student.class} />;
  }

  if (activeTab === 'ai-chatbot') {
    return <AIStudentChatbot studentId={student.id} />;
  }

  if (activeTab === 'study-hub') {
    return <FreePeriodActivities />;
  }

  if (activeTab === 'reports') {
    return (
      <div className="space-y-6">
        <div>
          <h2 className="text-2xl font-semibold">My Reports</h2>
          <p className="text-muted-foreground">View your attendance and performance reports</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card className="professional-card">
            <CardHeader>
              <CardTitle className="text-primary">Subject-wise Attendance</CardTitle>
              <CardDescription>Your attendance for each subject</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {student.subjects.slice(0, 5).map((subject, index) => {
                  const percentage = [92, 88, 85, 90, 87][index];
                  return (
                    <div key={subject} className="flex justify-between items-center">
                      <span className="text-sm">{subject}</span>
                      <div className="flex items-center space-x-2">
                        <Progress value={percentage} className="w-20" />
                        <span className="text-sm font-medium">{percentage}%</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>

          <Card className="professional-card">
            <CardHeader>
              <CardTitle className="text-primary">Performance Summary</CardTitle>
              <CardDescription>Your overall academic performance</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="text-center">
                  <div className="text-3xl font-bold text-primary">{attendanceStats.percentage}%</div>
                  <p className="text-sm text-muted-foreground">Overall Attendance</p>
                </div>
                <div className="grid grid-cols-2 gap-4 text-center">
                  <div>
                    <div className="text-xl font-semibold">{student.subjects.length}</div>
                    <p className="text-xs text-muted-foreground">Subjects Enrolled</p>
                  </div>
                  <div>
                    <div className="text-xl font-semibold">{student.grades.length}</div>
                    <p className="text-xs text-muted-foreground">Assessments Done</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Grades Card */}
          <Card className="professional-card md:col-span-2">
            <CardHeader>
              <CardTitle className="text-primary">Recent Grades</CardTitle>
              <CardDescription>Your latest assessment results</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {student.grades.map((grade, index) => (
                  <div key={index} className="p-4 border border-border rounded-lg bg-secondary/50">
                    <h4 className="font-medium text-sm text-foreground">{grade.subject}</h4>
                    <div className="flex justify-between items-center mt-2">
                      <span className="text-2xl font-bold text-primary">{grade.grade}</span>
                      <span className="text-sm text-muted-foreground">{grade.marks}/100</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (activeTab === 'certificate') {
    // Generate performance data for certificate
    const performanceData = {
      name: student.name,
      rollNo: student.rollNumber,
      course: `${student.stream} - ${student.class}`,
      year: `${student.year} Year, Semester ${student.semester}`,
      gpa: student.grades.reduce((sum, grade) => sum + (grade.marks / 10), 0) / student.grades.length,
      attendance: student.attendanceStats.percentage,
      assignmentCompletion: 94, // Mock data
      rank: student.attendanceStats.percentage >= 90 ? 'Gold' : student.attendanceStats.percentage >= 80 ? 'Silver' : 'Bronze' as 'Gold' | 'Silver' | 'Bronze',
      remarks: `${student.name} has demonstrated exceptional academic performance with consistent attendance and active participation in coursework. Shows strong analytical skills and dedication to learning.`
    };

    return <PerformanceCertificate studentData={performanceData} />;
  }

  if (activeTab === 'profile') {
    return (
      <div className="space-y-6">
        <div>
          <h2 className="text-2xl font-semibold">My Profile</h2>
          <p className="text-muted-foreground">View and manage your personal information</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Personal Information */}
          <Card className="professional-card lg:col-span-2">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-primary">
                <User className="w-5 h-5" />
                Personal Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Full Name</label>
                  <p className="text-base">{student.name}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Roll Number</label>
                  <p className="text-base">{student.rollNumber}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Email</label>
                  <p className="text-base flex items-center gap-2">
                    <Mail className="w-4 h-4" />
                    {student.email}
                  </p>
                </div>
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Phone</label>
                  <p className="text-base flex items-center gap-2">
                    <Phone className="w-4 h-4" />
                    {student.phone}
                  </p>
                </div>
                <div className="md:col-span-2">
                  <label className="text-sm font-medium text-muted-foreground">Address</label>
                  <p className="text-base flex items-start gap-2">
                    <MapPin className="w-4 h-4 mt-1" />
                    {student.address}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Academic Information */}
          <Card className="professional-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-primary">
                <GraduationCap className="w-5 h-5" />
                Academic Info
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm font-medium text-muted-foreground">Class</label>
                <p className="text-base">{student.class}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-muted-foreground">Stream</label>
                <p className="text-base">{student.stream}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-muted-foreground">Year</label>
                <p className="text-base">{student.year}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-muted-foreground">Semester</label>
                <p className="text-base">{student.semester}</p>
              </div>
            </CardContent>
          </Card>

          {/* Parent Information */}
          {parent && (
            <Card className="professional-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-primary">
                  <Users className="w-5 h-5" />
                  Parent/Guardian
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Name</label>
                  <p className="text-base">{parent.name}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Relationship</label>
                  <p className="text-base">{parent.relationship}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Contact</label>
                  <p className="text-base">{parent.phone}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Occupation</label>
                  <p className="text-base">{parent.occupation}</p>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Subjects */}
          <Card className="professional-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-primary">
                <BookOpen className="w-5 h-5" />
                Enrolled Subjects
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {student.subjects.map((subject, index) => (
                  <Badge key={index} variant="outline" className="mr-2 mb-2">
                    {subject}
                  </Badge>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return null;
}