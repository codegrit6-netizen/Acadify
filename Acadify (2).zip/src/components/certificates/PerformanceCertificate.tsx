import React from 'react';
import { Card } from '../ui/card';
import { Badge } from '../ui/badge';
import { Separator } from '../ui/separator';
import { LineChart, Line, XAxis, YAxis, ResponsiveContainer } from 'recharts';
import { Award, ShieldCheck, FileText, TrendingUp } from 'lucide-react';

// Mock chart data for marks trend
const marksData = [
  { month: 'Aug', marks: 78 },
  { month: 'Sep', marks: 82 },
  { month: 'Oct', marks: 85 },
  { month: 'Nov', marks: 88 },
  { month: 'Dec', marks: 91 },
  { month: 'Jan', marks: 89 }
];

interface PerformanceCertificateProps {
  studentData: {
    name: string;
    rollNo: string;
    course: string;
    year: string;
    gpa: number;
    attendance: number;
    assignmentCompletion: number;
    rank: 'Gold' | 'Silver' | 'Bronze';
    remarks: string;
  };
}

export function PerformanceCertificate({ studentData }: PerformanceCertificateProps) {
  const certificateId = `MREC-${studentData.rollNo}-${new Date().getFullYear()}`;
  
  const getRankColor = (rank: string) => {
    switch (rank) {
      case 'Gold': return 'bg-gradient-to-r from-yellow-400 via-yellow-500 to-yellow-600 text-white shadow-lg shadow-yellow-500/30';
      case 'Silver': return 'bg-gradient-to-r from-gray-300 via-gray-400 to-gray-500 text-white shadow-lg shadow-gray-400/30';
      case 'Bronze': return 'bg-gradient-to-r from-orange-400 via-orange-500 to-orange-600 text-white shadow-lg shadow-orange-500/30';
      default: return 'bg-primary text-primary-foreground';
    }
  };

  const getRankBackground = (rank: string) => {
    switch (rank) {
      case 'Gold': return 'bg-gradient-to-br from-yellow-50 via-yellow-100 to-amber-50 border-yellow-200';
      case 'Silver': return 'bg-gradient-to-br from-gray-50 via-gray-100 to-slate-50 border-gray-200';
      case 'Bronze': return 'bg-gradient-to-br from-orange-50 via-orange-100 to-amber-50 border-orange-200';
      default: return 'bg-gradient-to-br from-primary-50 to-secondary-50 border-primary-200';
    }
  };

  const getRankAccent = (rank: string) => {
    switch (rank) {
      case 'Gold': return 'border-yellow-300 shadow-yellow-200/50';
      case 'Silver': return 'border-gray-300 shadow-gray-200/50';
      case 'Bronze': return 'border-orange-300 shadow-orange-200/50';
      default: return 'border-primary-300 shadow-primary-200/50';
    }
  };

  const getRankIcon = (rank: string) => {
    return <Award className="w-5 h-5" />;
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      <Card className={`p-8 professional-card border-2 shadow-xl ${getRankBackground(studentData.rank)} ${getRankAccent(studentData.rank)}`}>
        {/* Header Section */}
        <div className={`flex items-center justify-between mb-8 pb-6 border-b-2 ${
          studentData.rank === 'Gold' ? 'border-yellow-300/50' : 
          studentData.rank === 'Silver' ? 'border-gray-300/50' : 
          'border-orange-300/50'
        }`}>
          <div>
            <h1 className="text-2xl font-bold text-foreground mb-1">
              Malla Reddy Engineering College For Women
            </h1>
            <p className="text-muted-foreground">(Autonomous Institution)</p>
          </div>
          <div className="text-right">
            <div className={`w-16 h-16 rounded-full flex items-center justify-center mb-2 shadow-lg ${
              studentData.rank === 'Gold' ? 'bg-gradient-to-br from-yellow-400 to-yellow-600' : 
              studentData.rank === 'Silver' ? 'bg-gradient-to-br from-gray-400 to-gray-600' : 
              'bg-gradient-to-br from-orange-400 to-orange-600'
            }`}>
              <ShieldCheck className="w-8 h-8 text-white" />
            </div>
            <p className="text-sm font-medium text-primary">ACADIFY</p>
          </div>
        </div>

        {/* Certificate Title */}
        <div className="text-center mb-8 relative">
          {/* Decorative elements based on rank */}
          <div className="absolute -top-2 left-1/2 transform -translate-x-1/2 flex gap-2">
            {studentData.rank === 'Gold' && (
              <>
                <div className="w-2 h-2 bg-yellow-400 rounded-full animate-pulse"></div>
                <div className="w-2 h-2 bg-yellow-500 rounded-full animate-pulse delay-75"></div>
                <div className="w-2 h-2 bg-yellow-400 rounded-full animate-pulse delay-150"></div>
              </>
            )}
            {studentData.rank === 'Silver' && (
              <>
                <div className="w-2 h-2 bg-gray-400 rounded-full animate-pulse"></div>
                <div className="w-2 h-2 bg-gray-500 rounded-full animate-pulse delay-75"></div>
                <div className="w-2 h-2 bg-gray-400 rounded-full animate-pulse delay-150"></div>
              </>
            )}
            {studentData.rank === 'Bronze' && (
              <>
                <div className="w-2 h-2 bg-orange-400 rounded-full animate-pulse"></div>
                <div className="w-2 h-2 bg-orange-500 rounded-full animate-pulse delay-75"></div>
                <div className="w-2 h-2 bg-orange-400 rounded-full animate-pulse delay-150"></div>
              </>
            )}
          </div>
          
          <h2 className="text-3xl font-bold text-primary mb-2">
            Acadify Performance Certificate
          </h2>
          <p className="text-muted-foreground">Academic Performance & Skills Assessment</p>
          <div className={`mt-4 inline-flex items-center gap-2 px-4 py-2 rounded-full ${
            studentData.rank === 'Gold' ? 'bg-yellow-50 border border-yellow-200' : 
            studentData.rank === 'Silver' ? 'bg-gray-50 border border-gray-200' : 
            'bg-orange-50 border border-orange-200'
          }`}>
            <FileText className="w-4 h-4 text-secondary-foreground" />
            <span className="text-sm font-medium text-secondary-foreground">Certificate ID: {certificateId}</span>
          </div>
        </div>

        {/* Student Information Block */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8 p-6 bg-secondary/50 rounded-lg border border-border">
          <div className="space-y-3">
            <div>
              <label className="text-sm font-medium text-muted-foreground uppercase tracking-wide">Student Name</label>
              <p className="text-lg font-semibold text-foreground">{studentData.name}</p>
            </div>
            <div>
              <label className="text-sm font-medium text-muted-foreground uppercase tracking-wide">Roll Number</label>
              <p className="text-lg font-semibold text-foreground">{studentData.rollNo}</p>
            </div>
          </div>
          <div className="space-y-3">
            <div>
              <label className="text-sm font-medium text-muted-foreground uppercase tracking-wide">Course</label>
              <p className="text-lg font-semibold text-foreground">{studentData.course}</p>
            </div>
            <div>
              <label className="text-sm font-medium text-muted-foreground uppercase tracking-wide">Academic Year</label>
              <p className="text-lg font-semibold text-foreground">{studentData.year}</p>
            </div>
          </div>
        </div>

        {/* Performance Analysis Section */}
        <div className="mb-8">
          <h3 className="text-xl font-bold text-foreground mb-6 flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-primary" />
            Performance Analysis
          </h3>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Performance Metrics */}
            <div className="space-y-4">
              <div className="p-4 bg-success/10 rounded-lg border border-success/20">
                <div className="flex justify-between items-center">
                  <span className="font-medium text-foreground">GPA</span>
                  <span className="text-2xl font-bold text-success">{studentData.gpa.toFixed(2)}</span>
                </div>
              </div>
              
              <div className="p-4 bg-primary/10 rounded-lg border border-primary/20">
                <div className="flex justify-between items-center">
                  <span className="font-medium text-foreground">Attendance</span>
                  <span className="text-2xl font-bold text-primary">{studentData.attendance}%</span>
                </div>
              </div>
              
              <div className="p-4 bg-accent/10 rounded-lg border border-accent/20">
                <div className="flex justify-between items-center">
                  <span className="font-medium text-foreground">Assignment Completion</span>
                  <span className="text-2xl font-bold text-accent">{studentData.assignmentCompletion}%</span>
                </div>
              </div>
            </div>

            {/* Marks Trend Chart */}
            <div className="p-4 bg-muted/30 rounded-lg border border-border">
              <h4 className="font-semibold text-foreground mb-3">Marks Trend (6 Months)</h4>
              <div className="h-32">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={marksData}>
                    <XAxis dataKey="month" axisLine={false} tickLine={false} className="text-xs" />
                    <YAxis hide />
                    <Line 
                      type="monotone" 
                      dataKey="marks" 
                      stroke="var(--primary)" 
                      strokeWidth={3}
                      dot={{ r: 4, fill: 'var(--primary)' }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>

          {/* Remarks */}
          <div className="mt-6 p-4 bg-warning/10 rounded-lg border border-warning/20">
            <h4 className="font-semibold text-foreground mb-2">Academic Remarks</h4>
            <p className="text-foreground">{studentData.remarks}</p>
          </div>
        </div>

        {/* Overall Rank/Level */}
        <div className="text-center mb-8">
          <h3 className="text-lg font-bold text-foreground mb-6">Performance Level</h3>
          <div className={`inline-flex items-center gap-3 px-8 py-4 text-xl font-bold rounded-xl ${getRankColor(studentData.rank)} border-2 border-white/30 transform hover:scale-105 transition-transform duration-300`}>
            {getRankIcon(studentData.rank)}
            {studentData.rank} Level Achiever
          </div>
          <div className="mt-4 max-w-md mx-auto">
            <div className={`p-4 rounded-lg ${studentData.rank === 'Gold' ? 'bg-yellow-50 border border-yellow-200' : 
              studentData.rank === 'Silver' ? 'bg-gray-50 border border-gray-200' : 
              'bg-orange-50 border border-orange-200'}`}>
              <p className="text-sm text-muted-foreground">
                {studentData.rank === 'Gold' && "🏆 Outstanding academic excellence with consistent high performance"}
                {studentData.rank === 'Silver' && "🥈 Commendable academic achievement with strong consistent performance"}
                {studentData.rank === 'Bronze' && "🥉 Good academic performance with steady progress and improvement"}
              </p>
            </div>
          </div>
        </div>

        {/* Eligibility Note */}
        <div className="mb-8 p-4 bg-info/10 border border-info/20 rounded-lg">
          <p className="text-center text-info font-medium">
            📋 This certificate can be used by government bodies or companies to evaluate internship eligibility and academic performance.
          </p>
        </div>

        <Separator className="mb-8" />

        {/* Signatures Area */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="text-center p-4 border-t-2 border-border">
            <div className="h-16 mb-2 flex items-end justify-center">
              <div className="w-32 h-8 bg-muted rounded border-b-2 border-border flex items-center justify-center">
                <span className="text-xs text-muted-foreground">Digital Signature</span>
              </div>
            </div>
            <p className="font-semibold text-foreground">Head of Department</p>
            <p className="text-sm text-muted-foreground">Computer Science & Engineering</p>
          </div>
          
          <div className="text-center p-4 border-t-2 border-border">
            <div className="h-16 mb-2 flex items-end justify-center">
              <div className="w-32 h-8 bg-muted rounded border-b-2 border-border flex items-center justify-center">
                <span className="text-xs text-muted-foreground">Digital Signature</span>
              </div>
            </div>
            <p className="font-semibold text-foreground">Training & Placement Officer</p>
            <p className="text-sm text-muted-foreground">MREC-W</p>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-8 pt-6 border-t border-border text-center">
          <p className="text-sm text-muted-foreground">
            Generated on {new Date().toLocaleDateString('en-US', { 
              year: 'numeric', 
              month: 'long', 
              day: 'numeric' 
            })} • Powered by Acadify Academic Management System
          </p>
        </div>
      </Card>
    </div>
  );
}