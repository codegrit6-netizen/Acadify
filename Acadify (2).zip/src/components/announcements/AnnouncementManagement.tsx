import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Textarea } from '../ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Badge } from '../ui/badge';
import { Separator } from '../ui/separator';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { Alert, AlertDescription } from '../ui/alert';
import { getAllAnnouncements, createAnnouncement, updateAnnouncement, deleteAnnouncement, classes } from '../../data/mockDatabase';
import type { Announcement, Teacher, Admin } from '../../data/mockDatabase';
import { 
  Plus, 
  Edit2, 
  Trash2, 
  Send,
  Eye,
  EyeOff,
  Clock,
  Users,
  AlertTriangle,
  CheckCircle,
  Info,
  Megaphone
} from 'lucide-react';

interface AnnouncementManagementProps {
  user: Teacher | Admin;
}

export function AnnouncementManagement({ user }: AnnouncementManagementProps) {
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [editingAnnouncement, setEditingAnnouncement] = useState<Announcement | null>(null);
  const [formData, setFormData] = useState({
    title: '',
    content: '',
    category: 'general' as const,
    priority: 'medium' as const,
    targetAudience: 'all' as string,
    expiresAt: ''
  });

  useEffect(() => {
    const allAnnouncements = getAllAnnouncements();
    setAnnouncements(allAnnouncements);
  }, []);

  const resetForm = () => {
    setFormData({
      title: '',
      content: '',
      category: 'general',
      priority: 'medium',
      targetAudience: 'all',
      expiresAt: ''
    });
    setEditingAnnouncement(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const announcementData = {
      title: formData.title,
      content: formData.content,
      author: user.id,
      authorName: user.name,
      authorType: user.type as 'teacher' | 'admin',
      targetAudience: formData.targetAudience === 'all' ? 'all' as const : 
                     formData.targetAudience === 'students' ? 'students' as const :
                     formData.targetAudience === 'teachers' ? 'teachers' as const :
                     formData.targetAudience === 'parents' ? 'parents' as const :
                     [formData.targetAudience], // For specific classes
      priority: formData.priority,
      category: formData.category,
      isActive: true,
      expiresAt: formData.expiresAt || undefined
    };

    if (editingAnnouncement) {
      const updated = updateAnnouncement(editingAnnouncement.id, announcementData);
      if (updated) {
        setAnnouncements(prev => prev.map(a => a.id === updated.id ? updated : a));
      }
    } else {
      const newAnnouncement = createAnnouncement(announcementData);
      setAnnouncements(prev => [newAnnouncement, ...prev]);
    }

    resetForm();
    setIsCreateDialogOpen(false);
  };

  const handleEdit = (announcement: Announcement) => {
    setEditingAnnouncement(announcement);
    setFormData({
      title: announcement.title,
      content: announcement.content,
      category: announcement.category,
      priority: announcement.priority,
      targetAudience: Array.isArray(announcement.targetAudience) 
        ? announcement.targetAudience[0] 
        : announcement.targetAudience,
      expiresAt: announcement.expiresAt ? announcement.expiresAt.split('T')[0] : ''
    });
    setIsCreateDialogOpen(true);
  };

  const handleDelete = (announcementId: string) => {
    if (window.confirm('Are you sure you want to delete this announcement?')) {
      const success = deleteAnnouncement(announcementId);
      if (success) {
        setAnnouncements(prev => prev.filter(a => a.id !== announcementId));
      }
    }
  };

  const toggleVisibility = (announcement: Announcement) => {
    const updated = updateAnnouncement(announcement.id, { isActive: !announcement.isActive });
    if (updated) {
      setAnnouncements(prev => prev.map(a => a.id === updated.id ? updated : a));
    }
  };

  const getPriorityIcon = (priority: string) => {
    switch (priority) {
      case 'urgent':
        return <AlertTriangle className="w-4 h-4 text-red-500" />;
      case 'high':
        return <AlertTriangle className="w-4 h-4 text-orange-500" />;
      case 'medium':
        return <Info className="w-4 h-4 text-blue-500" />;
      case 'low':
        return <CheckCircle className="w-4 h-4 text-green-500" />;
      default:
        return <Info className="w-4 h-4 text-gray-500" />;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'urgent':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'high':
        return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'medium':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'low':
        return 'bg-green-100 text-green-800 border-green-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getTargetAudienceDisplay = (targetAudience: any) => {
    if (targetAudience === 'all') return 'Everyone';
    if (typeof targetAudience === 'string') return targetAudience.charAt(0).toUpperCase() + targetAudience.slice(1);
    if (Array.isArray(targetAudience)) return targetAudience.join(', ');
    return 'Unknown';
  };

  const userAnnouncements = announcements.filter(a => a.author === user.id);
  const totalReads = userAnnouncements.reduce((sum, a) => sum + (a.readBy?.length || 0), 0);
  const activeAnnouncements = userAnnouncements.filter(a => a.isActive).length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="gradient-text">Announcement Management</h1>
          <p className="text-muted-foreground">Create and manage announcements for students and parents</p>
        </div>
        <Dialog open={isCreateDialogOpen} onOpenChange={(open) => {
          setIsCreateDialogOpen(open);
          if (!open) resetForm();
        }}>
          <DialogTrigger asChild>
            <Button className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600">
              <Plus className="w-4 h-4 mr-2" />
              New Announcement
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                {editingAnnouncement ? 'Edit Announcement' : 'Create New Announcement'}
              </DialogTitle>
              <DialogDescription>
                Share important information with students, parents, and faculty members.
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="title">Title</Label>
                <Input
                  id="title"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  placeholder="Enter announcement title"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="content">Content</Label>
                <Textarea
                  id="content"
                  value={formData.content}
                  onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                  placeholder="Enter announcement content"
                  rows={6}
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="category">Category</Label>
                  <Select value={formData.category} onValueChange={(value: any) => setFormData({ ...formData, category: value })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="general">General</SelectItem>
                      <SelectItem value="academic">Academic</SelectItem>
                      <SelectItem value="exams">Exams</SelectItem>
                      <SelectItem value="assignments">Assignments</SelectItem>
                      <SelectItem value="events">Events</SelectItem>
                      <SelectItem value="holidays">Holidays</SelectItem>
                      <SelectItem value="administrative">Administrative</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="priority">Priority</Label>
                  <Select value={formData.priority} onValueChange={(value: any) => setFormData({ ...formData, priority: value })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="urgent">Urgent</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="targetAudience">Target Audience</Label>
                <Select value={formData.targetAudience} onValueChange={(value) => setFormData({ ...formData, targetAudience: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Everyone</SelectItem>
                    <SelectItem value="students">Students Only</SelectItem>
                    <SelectItem value="teachers">Teachers Only</SelectItem>
                    <SelectItem value="parents">Parents Only</SelectItem>
                    <Separator />
                    {classes.map((cls) => (
                      <SelectItem key={cls.id} value={cls.id}>
                        {cls.name} ({cls.stream})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="expiresAt">Expiry Date (Optional)</Label>
                <Input
                  id="expiresAt"
                  type="date"
                  value={formData.expiresAt}
                  onChange={(e) => setFormData({ ...formData, expiresAt: e.target.value })}
                />
              </div>

              <div className="flex justify-end space-x-2 pt-4">
                <Button type="button" variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" className="bg-gradient-to-r from-purple-500 to-pink-500">
                  <Send className="w-4 h-4 mr-2" />
                  {editingAnnouncement ? 'Update' : 'Publish'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Your Announcements</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-semibold gradient-text">{userAnnouncements.length}</div>
            <p className="text-xs text-muted-foreground">{activeAnnouncements} active</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Total Reads</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-semibold gradient-text">{totalReads}</div>
            <p className="text-xs text-muted-foreground">Across all announcements</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Average Engagement</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-semibold gradient-text">
              {userAnnouncements.length > 0 ? Math.round(totalReads / userAnnouncements.length) : 0}
            </div>
            <p className="text-xs text-muted-foreground">Reads per announcement</p>
          </CardContent>
        </Card>
      </div>

      {/* Announcements List */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Megaphone className="w-5 h-5" />
            Your Announcements
          </CardTitle>
          <CardDescription>
            Manage your published announcements
          </CardDescription>
        </CardHeader>
        <CardContent>
          {userAnnouncements.length === 0 ? (
            <div className="text-center py-12">
              <Megaphone className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="font-medium mb-2">No announcements yet</h3>
              <p className="text-muted-foreground text-sm mb-4">
                Create your first announcement to start communicating with students and parents.
              </p>
              <Button 
                onClick={() => setIsCreateDialogOpen(true)}
                className="bg-gradient-to-r from-purple-500 to-pink-500"
              >
                <Plus className="w-4 h-4 mr-2" />
                Create Announcement
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              {userAnnouncements.map((announcement) => (
                <div key={announcement.id} className="border rounded-lg p-4 space-y-3">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <h3 className="font-medium">{announcement.title}</h3>
                        {!announcement.isActive && (
                          <Badge variant="secondary" className="text-xs">Hidden</Badge>
                        )}
                      </div>
                      <div className="flex items-center gap-2 mb-2">
                        <Badge className={`text-xs ${getPriorityColor(announcement.priority)}`}>
                          {getPriorityIcon(announcement.priority)}
                          <span className="ml-1 capitalize">{announcement.priority}</span>
                        </Badge>
                        <Badge variant="outline" className="text-xs capitalize">
                          {announcement.category}
                        </Badge>
                        <Badge variant="outline" className="text-xs">
                          <Users className="w-3 h-3 mr-1" />
                          {getTargetAudienceDisplay(announcement.targetAudience)}
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground line-clamp-2">
                        {announcement.content}
                      </p>
                    </div>
                    <div className="flex items-center space-x-2 flex-shrink-0">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => toggleVisibility(announcement)}
                      >
                        {announcement.isActive ? (
                          <>
                            <Eye className="w-3 h-3 mr-1" />
                            Visible
                          </>
                        ) : (
                          <>
                            <EyeOff className="w-3 h-3 mr-1" />
                            Hidden
                          </>
                        )}
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleEdit(announcement)}
                      >
                        <Edit2 className="w-3 h-3" />
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleDelete(announcement.id)}
                        className="text-red-600 hover:text-red-700"
                      >
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>
                  <div className="flex items-center justify-between text-xs text-muted-foreground">
                    <div className="flex items-center gap-4">
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {formatDate(announcement.createdAt)}
                      </span>
                      {announcement.expiresAt && (
                        <span className="text-orange-600">
                          Expires: {new Date(announcement.expiresAt).toLocaleDateString()}
                        </span>
                      )}
                    </div>
                    <span>{announcement.readBy?.length || 0} people read this</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}