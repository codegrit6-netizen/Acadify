import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Separator } from '../ui/separator';
import { getAnnouncementsForUser, markAnnouncementAsRead } from '../../data/mockDatabase';
import type { Announcement } from '../../data/mockDatabase';
import { 
  Megaphone, 
  Clock, 
  User,
  Search,
  Filter,
  CheckCircle,
  AlertTriangle,
  Info,
  Calendar
} from 'lucide-react';

interface AnnouncementsViewProps {
  userId: string;
  userType: string;
  userClass?: string;
}

export function AnnouncementsView({ userId, userType, userClass }: AnnouncementsViewProps) {
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [filteredAnnouncements, setFilteredAnnouncements] = useState<Announcement[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedPriority, setSelectedPriority] = useState<string>('all');

  useEffect(() => {
    const userAnnouncements = getAnnouncementsForUser(userId, userType, userClass);
    setAnnouncements(userAnnouncements);
    setFilteredAnnouncements(userAnnouncements);
  }, [userId, userType, userClass]);

  useEffect(() => {
    let filtered = announcements;

    // Filter by search query
    if (searchQuery) {
      filtered = filtered.filter(announcement => 
        announcement.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        announcement.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
        announcement.authorName.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    // Filter by category
    if (selectedCategory !== 'all') {
      filtered = filtered.filter(announcement => announcement.category === selectedCategory);
    }

    // Filter by priority
    if (selectedPriority !== 'all') {
      filtered = filtered.filter(announcement => announcement.priority === selectedPriority);
    }

    setFilteredAnnouncements(filtered);
  }, [announcements, searchQuery, selectedCategory, selectedPriority]);

  const handleMarkAsRead = (announcementId: string) => {
    markAnnouncementAsRead(announcementId, userId);
    const updatedAnnouncements = announcements.map(announcement => {
      if (announcement.id === announcementId) {
        return {
          ...announcement,
          readBy: [...(announcement.readBy || []), userId]
        };
      }
      return announcement;
    });
    setAnnouncements(updatedAnnouncements);
  };

  const getPriorityIcon = (priority: string) => {
    switch (priority) {
      case 'urgent':
        return <AlertTriangle className="w-4 h-4 text-red-500" />;
      case 'high':
        return <AlertTriangle className="w-4 h-4 text-orange-500" />;
      case 'medium':
        return <Info className="w-4 h-4 text-blue-500" />;
      case 'low':
        return <CheckCircle className="w-4 h-4 text-green-500" />;
      default:
        return <Info className="w-4 h-4 text-gray-500" />;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'urgent':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'high':
        return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'medium':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'low':
        return 'bg-green-100 text-green-800 border-green-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'exams':
        return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'assignments':
        return 'bg-indigo-100 text-indigo-800 border-indigo-200';
      case 'events':
        return 'bg-pink-100 text-pink-800 border-pink-200';
      case 'holidays':
        return 'bg-emerald-100 text-emerald-800 border-emerald-200';
      case 'academic':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'administrative':
        return 'bg-gray-100 text-gray-800 border-gray-200';
      default:
        return 'bg-slate-100 text-slate-800 border-slate-200';
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInHours = Math.abs(now.getTime() - date.getTime()) / (1000 * 60 * 60);

    if (diffInHours < 24) {
      return `${Math.floor(diffInHours)}h ago`;
    } else if (diffInHours < 48) {
      return '1 day ago';
    } else {
      return date.toLocaleDateString('en-US', { 
        month: 'short', 
        day: 'numeric',
        year: date.getFullYear() !== now.getFullYear() ? 'numeric' : undefined
      });
    }
  };

  const isUnread = (announcement: Announcement) => {
    return !announcement.readBy?.includes(userId);
  };

  const unreadCount = announcements.filter(isUnread).length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="gradient-text">Announcements</h1>
            <p className="text-muted-foreground">Stay updated with important information and updates</p>
          </div>
          <div className="flex items-center space-x-2">
            <Badge variant="outline" className="border-purple-200 text-purple-700">
              <Megaphone className="w-3 h-3 mr-1" />
              {announcements.length} Total
            </Badge>
            {unreadCount > 0 && (
              <Badge className="bg-gradient-to-r from-red-500 to-pink-500 text-white">
                {unreadCount} Unread
              </Badge>
            )}
          </div>
        </div>

        {/* Filters */}
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
            <Input
              placeholder="Search announcements..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          <div className="flex gap-2">
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                <SelectItem value="general">General</SelectItem>
                <SelectItem value="academic">Academic</SelectItem>
                <SelectItem value="exams">Exams</SelectItem>
                <SelectItem value="assignments">Assignments</SelectItem>
                <SelectItem value="events">Events</SelectItem>
                <SelectItem value="holidays">Holidays</SelectItem>
                <SelectItem value="administrative">Administrative</SelectItem>
              </SelectContent>
            </Select>
            <Select value={selectedPriority} onValueChange={setSelectedPriority}>
              <SelectTrigger className="w-32">
                <SelectValue placeholder="Priority" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Priorities</SelectItem>
                <SelectItem value="urgent">Urgent</SelectItem>
                <SelectItem value="high">High</SelectItem>
                <SelectItem value="medium">Medium</SelectItem>
                <SelectItem value="low">Low</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      {/* Announcements List */}
      <div className="space-y-4">
        {filteredAnnouncements.length === 0 ? (
          <Card className="text-center py-12">
            <CardContent>
              <Megaphone className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="font-medium mb-2">No announcements found</h3>
              <p className="text-muted-foreground text-sm">
                {searchQuery || selectedCategory !== 'all' || selectedPriority !== 'all'
                  ? 'Try adjusting your filters to see more announcements.'
                  : 'No announcements available at the moment.'}
              </p>
            </CardContent>
          </Card>
        ) : (
          filteredAnnouncements.map((announcement) => (
            <Card 
              key={announcement.id}
              className={`transition-all duration-200 hover:shadow-lg ${
                isUnread(announcement) 
                  ? 'border-l-4 border-l-purple-500 bg-gradient-to-r from-purple-50/50 to-transparent' 
                  : ''
              }`}
            >
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1 space-y-2">
                    <div className="flex items-center gap-2 flex-wrap">
                      <CardTitle className="text-lg leading-tight">{announcement.title}</CardTitle>
                      {isUnread(announcement) && (
                        <Badge variant="secondary" className="text-xs bg-purple-100 text-purple-700">
                          New
                        </Badge>
                      )}
                    </div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <Badge className={`text-xs ${getPriorityColor(announcement.priority)}`}>
                        {getPriorityIcon(announcement.priority)}
                        <span className="ml-1 capitalize">{announcement.priority}</span>
                      </Badge>
                      <Badge className={`text-xs ${getCategoryColor(announcement.category)}`}>
                        <span className="capitalize">{announcement.category}</span>
                      </Badge>
                    </div>
                  </div>
                  <div className="text-right space-y-1 flex-shrink-0">
                    <p className="text-xs text-muted-foreground flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {formatDate(announcement.createdAt)}
                    </p>
                    <p className="text-xs text-muted-foreground flex items-center gap-1">
                      <User className="w-3 h-3" />
                      {announcement.authorName}
                    </p>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground leading-relaxed mb-4">
                  {announcement.content}
                </p>
                
                {announcement.expiresAt && (
                  <div className="flex items-center gap-1 text-xs text-orange-600 mb-3">
                    <Calendar className="w-3 h-3" />
                    Expires: {new Date(announcement.expiresAt).toLocaleDateString()}
                  </div>
                )}

                <div className="flex items-center justify-between">
                  <div className="text-xs text-muted-foreground">
                    {announcement.readBy?.length || 0} people have read this
                  </div>
                  {isUnread(announcement) && (
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleMarkAsRead(announcement.id)}
                      className="text-xs"
                    >
                      <CheckCircle className="w-3 h-3 mr-1" />
                      Mark as Read
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}