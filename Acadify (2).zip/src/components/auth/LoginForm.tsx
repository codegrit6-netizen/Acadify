import React, { useState } from 'react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { User, Lock } from 'lucide-react';
import acadifyLogo from 'figma:asset/ac242b88a3828f6beae2b12715e6e0c50cb74ea8.png';

interface LoginFormProps {
  onLogin: (userType: string, userId: string, password: string) => boolean;
}

export function LoginForm({ onLogin }: LoginFormProps) {
  const [userType, setUserType] = useState<string>('');
  const [userId, setUserId] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (userType && userId && password) {
      setIsLoading(true);
      setError('');
      
      const success = onLogin(userType, userId, password);
      
      if (!success) {
        setError('Invalid credentials. Please check your User ID and password.');
      }
      
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-background">
      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-background to-accent/5"></div>
      <Card className="w-full max-w-md relative z-10 professional-card shadow-xl border-2">
        <CardHeader className="space-y-1 text-center">
          <div className="mx-auto mb-6 flex items-center justify-center">
            <img 
              src={acadifyLogo} 
              alt="Acadify Logo" 
              className="w-32 h-auto object-contain"
            />
          </div>
          <CardTitle className="text-2xl font-semibold text-primary">Welcome to Acadify</CardTitle>
          <CardDescription className="text-muted-foreground">
            Sign in to access your institutional dashboard
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="userType" className="text-foreground font-medium">User Type</Label>
              <Select value={userType} onValueChange={setUserType}>
                <SelectTrigger className="input-field">
                  <SelectValue placeholder="Select your role" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="student">Student</SelectItem>
                  <SelectItem value="teacher">Teacher</SelectItem>
                  <SelectItem value="admin">Admin</SelectItem>
                  <SelectItem value="parent">Parent</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="userId" className="text-foreground font-medium">User ID</Label>
              <div className="relative">
                <User className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  id="userId"
                  placeholder="Enter your user ID"
                  value={userId}
                  onChange={(e) => setUserId(e.target.value)}
                  className="pl-10 input-field"
                />
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="password" className="text-foreground font-medium">Password</Label>
              <div className="relative">
                <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  id="password"
                  type="password"
                  placeholder="Enter your password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="pl-10 input-field"
                />
              </div>
            </div>
            
            {error && (
              <div className="p-3 rounded-lg bg-destructive/10 border border-destructive/20 text-destructive text-sm">
                {error}
              </div>
            )}
            
            <Button 
              type="submit" 
              className="w-full btn-primary" 
              disabled={!userType || !userId || !password || isLoading}
            >
              {isLoading ? 'Signing In...' : 'Sign In'}
            </Button>
          </form>
          
          <div className="text-center text-sm text-muted-foreground space-y-3 pt-4 border-t border-border">
            <p className="font-medium text-foreground">Demo Credentials:</p>
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="space-y-1 p-2 bg-secondary/50 rounded-lg">
                <p className="font-medium text-primary">Students:</p>
                <p>STU001 / arjun123</p>
                <p>STU002 / priya123</p>
                <p>STU003 / ravi123</p>
              </div>
              <div className="space-y-1 p-2 bg-secondary/50 rounded-lg">
                <p className="font-medium text-accent">Teachers:</p>
                <p>TCH001 / rajesh123</p>
                <p>TCH002 / meera123</p>
                <p>TCH003 / amit123</p>
              </div>
              <div className="space-y-1 p-2 bg-secondary/50 rounded-lg">
                <p className="font-medium text-success">Parents:</p>
                <p>PAR001 / vikram123</p>
                <p>PAR002 / sunita123</p>
                <p>PAR003 / lakshmi123</p>
              </div>
              <div className="space-y-1 p-2 bg-secondary/50 rounded-lg">
                <p className="font-medium text-warning">Admins:</p>
                <p>ADM001 / kavitha123</p>
                <p>ADM002 / suresh123</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}