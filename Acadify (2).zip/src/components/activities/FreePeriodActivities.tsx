import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Progress } from '../ui/progress';
import { Input } from '../ui/input';
import { Textarea } from '../ui/textarea';
import { 
  Brain, 
  Gamepad2, 
  BookOpen, 
  Palette, 
  Zap, 
  Heart, 
  Coffee,
  Target,
  Shuffle,
  CheckCircle,
  Clock,
  Trophy,
  Star,
  Lightbulb,
  Music,
  Headphones,
  Wind,
  Eye,
  Timer,
  PlayCircle,
  RefreshCw
} from 'lucide-react';

interface Activity {
  id: string;
  title: string;
  description: string;
  icon: React.ElementType;
  category: 'brain' | 'study' | 'creative' | 'relax' | 'quick';
  difficulty: 'easy' | 'medium' | 'hard';
  duration: string;
  points: number;
}

interface GameState {
  currentActivity: Activity | null;
  score: number;
  streak: number;
  timeRemaining: number;
  isActive: boolean;
}

export function FreePeriodActivities() {
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [gameState, setGameState] = useState<GameState>({
    currentActivity: null,
    score: 0,
    streak: 0,
    timeRemaining: 0,
    isActive: false
  });
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [userAnswer, setUserAnswer] = useState('');
  const [showResult, setShowResult] = useState(false);
  const [creativityPrompt, setCreativityPrompt] = useState('');
  const [isRelaxationActive, setIsRelaxationActive] = useState(false);
  const [breathingCycle, setBreathingCycle] = useState('inhale');

  const activities: Activity[] = [
    {
      id: 'word-scramble',
      title: 'Word Scramble Challenge',
      description: 'Unscramble academic vocabulary words',
      icon: Brain,
      category: 'brain',
      difficulty: 'medium',
      duration: '5 min',
      points: 150
    },
    {
      id: 'math-quick',
      title: 'Quick Math Sprint',
      description: 'Solve math problems as fast as you can',
      icon: Zap,
      category: 'brain',
      difficulty: 'easy',
      duration: '3 min',
      points: 100
    },
    {
      id: 'science-trivia',
      title: 'Science Trivia',
      description: 'Test your knowledge with fun science facts',
      icon: Lightbulb,
      category: 'study',
      difficulty: 'medium',
      duration: '7 min',
      points: 200
    },
    {
      id: 'flashcards',
      title: 'Digital Flashcards',
      description: 'Study with interactive flashcards',
      icon: BookOpen,
      category: 'study',
      difficulty: 'easy',
      duration: '10 min',
      points: 50
    },
    {
      id: 'creative-writing',
      title: 'Creative Writing Prompts',
      description: 'Express yourself with guided writing exercises',
      icon: Palette,
      category: 'creative',
      difficulty: 'medium',
      duration: '15 min',
      points: 120
    },
    {
      id: 'memory-game',
      title: 'Memory Palace',
      description: 'Train your memory with pattern sequences',
      icon: Target,
      category: 'brain',
      difficulty: 'hard',
      duration: '8 min',
      points: 250
    },
    {
      id: 'breathing-exercise',
      title: 'Mindful Breathing',
      description: 'Relax with guided breathing exercises',
      icon: Wind,
      category: 'relax',
      difficulty: 'easy',
      duration: '5 min',
      points: 75
    },
    {
      id: 'focus-music',
      title: 'Focus Sounds',
      description: 'Listen to concentration-enhancing audio',
      icon: Headphones,
      category: 'relax',
      difficulty: 'easy',
      duration: '15 min',
      points: 50
    },
    {
      id: 'language-phrases',
      title: 'Language Learning',
      description: 'Learn useful phrases in different languages',
      icon: Coffee,
      category: 'quick',
      difficulty: 'easy',
      duration: '5 min',
      points: 80
    },
    {
      id: 'fact-burst',
      title: 'Random Facts Burst',
      description: 'Discover fascinating facts from various subjects',
      icon: Star,
      category: 'quick',
      difficulty: 'easy',
      duration: '3 min',
      points: 60
    }
  ];

  const categories = [
    { id: 'all', label: 'All Activities', icon: Gamepad2 },
    { id: 'brain', label: 'Brain Training', icon: Brain },
    { id: 'study', label: 'Study Tools', icon: BookOpen },
    { id: 'creative', label: 'Creative Zone', icon: Palette },
    { id: 'relax', label: 'Relaxation', icon: Heart },
    { id: 'quick', label: 'Quick Learn', icon: Zap }
  ];

  const mathQuestions = [
    { question: "What is 15 × 8?", answer: "120" },
    { question: "What is 144 ÷ 12?", answer: "12" },
    { question: "What is 23 + 47?", answer: "70" },
    { question: "What is 100 - 36?", answer: "64" },
    { question: "What is 7²?", answer: "49" }
  ];

  const wordScrambles = [
    { scrambled: "HCEMISTRY", answer: "CHEMISTRY" },
    { scrambled: "SIPHYCS", answer: "PHYSICS" },
    { scrambled: "OGLOBYI", answer: "BIOLOGY" },
    { scrambled: "HTAMEMATICS", answer: "MATHEMATICS" },
    { scrambled: "OGEOGRAPHY", answer: "GEOGRAPHY" }
  ];

  const scienceTrivia = [
    { question: "What is the chemical symbol for gold?", answer: "AU" },
    { question: "How many bones are in an adult human body?", answer: "206" },
    { question: "What planet is known as the Red Planet?", answer: "MARS" },
    { question: "What gas do plants absorb from the atmosphere?", answer: "CARBON DIOXIDE" },
    { question: "What is the speed of light in a vacuum? (in km/s)", answer: "300000" }
  ];

  const creativePrompts = [
    "Write a short story about a student who discovers a magical classroom that only appears during free periods...",
    "Describe your ideal learning environment in detail - what would it look like, sound like, and feel like?",
    "Create a dialogue between two historical figures discussing modern technology...",
    "Write about a day when all the subjects in school came to life and started interacting with each other...",
    "Imagine you could teach a class to your teachers - what would you teach and why?"
  ];

  const randomFacts = [
    "Honey never spoils. Archaeologists have found pots of honey in ancient Egyptian tombs that are over 3,000 years old and still edible!",
    "A group of flamingos is called a 'flamboyance' - quite fitting for such colorful birds!",
    "The shortest war in history lasted only 38-45 minutes between Britain and Zanzibar in 1896.",
    "Bananas are berries, but strawberries aren't! Botanically speaking, bananas qualify as berries while strawberries are aggregate fruits.",
    "The human brain uses about 20% of the body's total energy, despite being only 2% of body weight."
  ];

  const languagePhrases = [
    { language: "Spanish", phrase: "¡Buena suerte!", meaning: "Good luck!", pronunciation: "BWAY-nah SWEHR-teh" },
    { language: "French", phrase: "Bon courage!", meaning: "Good luck/courage!", pronunciation: "bon koo-RAHZH" },
    { language: "German", phrase: "Viel Erfolg!", meaning: "Much success!", pronunciation: "feel er-FOLK" },
    { language: "Italian", phrase: "In bocca al lupo!", meaning: "Good luck! (lit: In the mouth of the wolf)", pronunciation: "in BOH-kah al LOO-poh" },
    { language: "Japanese", phrase: "頑張って!", meaning: "Good luck/Do your best!", pronunciation: "gan-BAH-teh" }
  ];

  const filteredActivities = activeCategory === 'all' 
    ? activities 
    : activities.filter(activity => activity.category === activeCategory);

  const startActivity = (activity: Activity) => {
    setGameState({
      currentActivity: activity,
      score: 0,
      streak: 0,
      timeRemaining: parseInt(activity.duration) * 60,
      isActive: true
    });
    setCurrentQuestionIndex(0);
    setUserAnswer('');
    setShowResult(false);

    if (activity.id === 'creative-writing') {
      const randomPrompt = creativePrompts[Math.floor(Math.random() * creativePrompts.length)];
      setCreativityPrompt(randomPrompt);
    }

    if (activity.id === 'breathing-exercise') {
      setIsRelaxationActive(true);
      startBreathingCycle();
    }
  };

  const startBreathingCycle = () => {
    let cycle = 0;
    const breathingStates = ['inhale', 'hold', 'exhale', 'hold'];
    const durations = [4000, 4000, 6000, 2000]; // milliseconds

    const runCycle = () => {
      setBreathingCycle(breathingStates[cycle]);
      setTimeout(() => {
        cycle = (cycle + 1) % breathingStates.length;
        if (isRelaxationActive) runCycle();
      }, durations[cycle]);
    };

    runCycle();
  };

  const checkAnswer = () => {
    if (!gameState.currentActivity) return;

    let isCorrect = false;
    let correctAnswer = '';

    if (gameState.currentActivity.id === 'math-quick') {
      correctAnswer = mathQuestions[currentQuestionIndex].answer;
      isCorrect = userAnswer.trim().toLowerCase() === correctAnswer.toLowerCase();
    } else if (gameState.currentActivity.id === 'word-scramble') {
      correctAnswer = wordScrambles[currentQuestionIndex].answer;
      isCorrect = userAnswer.trim().toLowerCase() === correctAnswer.toLowerCase();
    } else if (gameState.currentActivity.id === 'science-trivia') {
      correctAnswer = scienceTrivia[currentQuestionIndex].answer;
      isCorrect = userAnswer.trim().toLowerCase() === correctAnswer.toLowerCase();
    }

    if (isCorrect) {
      setGameState(prev => ({
        ...prev,
        score: prev.score + gameState.currentActivity!.points,
        streak: prev.streak + 1
      }));
    } else {
      setGameState(prev => ({
        ...prev,
        streak: 0
      }));
    }

    setShowResult(true);
    setTimeout(() => {
      if (currentQuestionIndex < 4) {
        setCurrentQuestionIndex(prev => prev + 1);
        setUserAnswer('');
        setShowResult(false);
      } else {
        endActivity();
      }
    }, 2000);
  };

  const endActivity = () => {
    setGameState(prev => ({
      ...prev,
      isActive: false
    }));
    setIsRelaxationActive(false);
  };

  const resetActivity = () => {
    setGameState({
      currentActivity: null,
      score: 0,
      streak: 0,
      timeRemaining: 0,
      isActive: false
    });
    setCurrentQuestionIndex(0);
    setUserAnswer('');
    setShowResult(false);
    setCreativityPrompt('');
    setIsRelaxationActive(false);
  };

  // Timer effect
  useEffect(() => {
    if (gameState.isActive && gameState.timeRemaining > 0) {
      const timer = setTimeout(() => {
        setGameState(prev => ({
          ...prev,
          timeRemaining: prev.timeRemaining - 1
        }));
      }, 1000);
      return () => clearTimeout(timer);
    } else if (gameState.timeRemaining === 0 && gameState.isActive) {
      endActivity();
    }
  }, [gameState.timeRemaining, gameState.isActive]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const renderActivityContent = () => {
    if (!gameState.currentActivity) return null;

    const activity = gameState.currentActivity;

    if (activity.id === 'math-quick') {
      const question = mathQuestions[currentQuestionIndex];
      return (
        <div className="space-y-6">
          <div className="text-center">
            <h3 className="text-2xl font-bold mb-4">Question {currentQuestionIndex + 1}/5</h3>
            <p className="text-xl mb-4">{question.question}</p>
            <Input
              value={userAnswer}
              onChange={(e) => setUserAnswer(e.target.value)}
              placeholder="Enter your answer"
              className="text-center text-lg max-w-xs mx-auto"
              onKeyPress={(e) => e.key === 'Enter' && !showResult && checkAnswer()}
            />
            {!showResult ? (
              <Button onClick={checkAnswer} className="mt-4 bg-gradient-to-r from-purple-500 to-pink-500">
                Submit Answer
              </Button>
            ) : (
              <div className="mt-4">
                <p className={`text-lg font-bold ${userAnswer.toLowerCase() === question.answer.toLowerCase() ? 'text-green-500' : 'text-red-500'}`}>
                  {userAnswer.toLowerCase() === question.answer.toLowerCase() ? '✓ Correct!' : `✗ Incorrect. Answer: ${question.answer}`}
                </p>
              </div>
            )}
          </div>
        </div>
      );
    }

    if (activity.id === 'word-scramble') {
      const scramble = wordScrambles[currentQuestionIndex];
      return (
        <div className="space-y-6">
          <div className="text-center">
            <h3 className="text-2xl font-bold mb-4">Word {currentQuestionIndex + 1}/5</h3>
            <p className="text-sm text-muted-foreground mb-2">Unscramble this academic word:</p>
            <p className="text-3xl font-bold text-purple-600 mb-4 tracking-widest">{scramble.scrambled}</p>
            <Input
              value={userAnswer}
              onChange={(e) => setUserAnswer(e.target.value)}
              placeholder="Enter the word"
              className="text-center text-lg max-w-xs mx-auto"
              onKeyPress={(e) => e.key === 'Enter' && !showResult && checkAnswer()}
            />
            {!showResult ? (
              <Button onClick={checkAnswer} className="mt-4 bg-gradient-to-r from-purple-500 to-pink-500">
                Submit Word
              </Button>
            ) : (
              <div className="mt-4">
                <p className={`text-lg font-bold ${userAnswer.toLowerCase() === scramble.answer.toLowerCase() ? 'text-green-500' : 'text-red-500'}`}>
                  {userAnswer.toLowerCase() === scramble.answer.toLowerCase() ? '✓ Correct!' : `✗ Answer: ${scramble.answer}`}
                </p>
              </div>
            )}
          </div>
        </div>
      );
    }

    if (activity.id === 'science-trivia') {
      const trivia = scienceTrivia[currentQuestionIndex];
      return (
        <div className="space-y-6">
          <div className="text-center">
            <h3 className="text-2xl font-bold mb-4">Science Question {currentQuestionIndex + 1}/5</h3>
            <p className="text-lg mb-4">{trivia.question}</p>
            <Input
              value={userAnswer}
              onChange={(e) => setUserAnswer(e.target.value)}
              placeholder="Enter your answer"
              className="text-center text-lg max-w-xs mx-auto"
              onKeyPress={(e) => e.key === 'Enter' && !showResult && checkAnswer()}
            />
            {!showResult ? (
              <Button onClick={checkAnswer} className="mt-4 bg-gradient-to-r from-purple-500 to-pink-500">
                Submit Answer
              </Button>
            ) : (
              <div className="mt-4">
                <p className={`text-lg font-bold ${userAnswer.toLowerCase() === trivia.answer.toLowerCase() ? 'text-green-500' : 'text-red-500'}`}>
                  {userAnswer.toLowerCase() === trivia.answer.toLowerCase() ? '✓ Correct!' : `✗ Answer: ${trivia.answer}`}
                </p>
              </div>
            )}
          </div>
        </div>
      );
    }

    if (activity.id === 'creative-writing') {
      return (
        <div className="space-y-6">
          <div>
            <h3 className="text-xl font-bold mb-4">Creative Writing Exercise</h3>
            <div className="bg-gradient-to-r from-purple-100 to-pink-100 p-4 rounded-lg mb-4">
              <p className="text-gray-700">{creativityPrompt}</p>
            </div>
            <Textarea
              placeholder="Start writing your creative response here..."
              className="min-h-48 resize-none"
            />
            <div className="flex justify-between items-center mt-4">
              <Button 
                variant="outline" 
                onClick={() => setCreativityPrompt(creativePrompts[Math.floor(Math.random() * creativePrompts.length)])}
              >
                <Shuffle className="w-4 h-4 mr-2" />
                New Prompt
              </Button>
              <Button className="bg-gradient-to-r from-purple-500 to-pink-500">
                Save Draft
              </Button>
            </div>
          </div>
        </div>
      );
    }

    if (activity.id === 'breathing-exercise') {
      return (
        <div className="space-y-6 text-center">
          <h3 className="text-2xl font-bold mb-4">Mindful Breathing Exercise</h3>
          <div className="space-y-8">
            <div className={`w-32 h-32 mx-auto rounded-full bg-gradient-to-br from-blue-400 to-purple-500 flex items-center justify-center transition-transform duration-1000 ${
              breathingCycle === 'inhale' ? 'scale-110' : breathingCycle === 'exhale' ? 'scale-90' : 'scale-100'
            }`}>
              <Wind className="w-16 h-16 text-white" />
            </div>
            <div className="space-y-2">
              <p className="text-2xl font-bold capitalize text-purple-600">{breathingCycle}</p>
              <p className="text-muted-foreground">
                {breathingCycle === 'inhale' && "Breathe in slowly through your nose"}
                {breathingCycle === 'exhale' && "Breathe out slowly through your mouth"}
                {breathingCycle === 'hold' && "Hold your breath gently"}
              </p>
            </div>
            <Button 
              onClick={() => setIsRelaxationActive(false)} 
              variant="outline"
              className="mt-8"
            >
              Stop Exercise
            </Button>
          </div>
        </div>
      );
    }

    if (activity.id === 'fact-burst') {
      const randomFact = randomFacts[Math.floor(Math.random() * randomFacts.length)];
      return (
        <div className="space-y-6 text-center">
          <h3 className="text-2xl font-bold mb-4">Random Fact</h3>
          <div className="bg-gradient-to-r from-yellow-100 to-orange-100 p-6 rounded-lg">
            <Star className="w-8 h-8 text-orange-500 mx-auto mb-4" />
            <p className="text-gray-700 text-lg leading-relaxed">{randomFact}</p>
          </div>
          <Button 
            onClick={() => window.location.reload()} 
            className="bg-gradient-to-r from-orange-500 to-yellow-500"
          >
            <RefreshCw className="w-4 h-4 mr-2" />
            Another Fact
          </Button>
        </div>
      );
    }

    if (activity.id === 'language-phrases') {
      const randomPhrase = languagePhrases[Math.floor(Math.random() * languagePhrases.length)];
      return (
        <div className="space-y-6 text-center">
          <h3 className="text-2xl font-bold mb-4">Language Learning</h3>
          <div className="space-y-4">
            <Badge variant="outline" className="text-lg px-4 py-2">{randomPhrase.language}</Badge>
            <div className="bg-gradient-to-r from-green-100 to-blue-100 p-6 rounded-lg space-y-3">
              <p className="text-2xl font-bold text-green-700">{randomPhrase.phrase}</p>
              <p className="text-lg text-gray-700">{randomPhrase.meaning}</p>
              <p className="text-sm text-muted-foreground">Pronunciation: {randomPhrase.pronunciation}</p>
            </div>
          </div>
          <Button 
            onClick={() => window.location.reload()} 
            className="bg-gradient-to-r from-green-500 to-blue-500"
          >
            <RefreshCw className="w-4 h-4 mr-2" />
            New Phrase
          </Button>
        </div>
      );
    }

    if (activity.id === 'focus-music') {
      return (
        <div className="space-y-6 text-center">
          <h3 className="text-2xl font-bold mb-4">Focus Sounds</h3>
          <div className="grid grid-cols-2 gap-4">
            {['Rain', 'Forest', 'Ocean', 'Cafe'].map((sound) => (
              <Button
                key={sound}
                variant="outline"
                className="h-20 flex flex-col items-center justify-center space-y-2 hover:bg-gradient-to-r hover:from-purple-100 hover:to-pink-100"
              >
                <Music className="w-6 h-6" />
                <span>{sound}</span>
              </Button>
            ))}
          </div>
          <div className="bg-gradient-to-r from-purple-100 to-pink-100 p-4 rounded-lg">
            <p className="text-muted-foreground">Choose a sound to help you focus and concentrate</p>
          </div>
        </div>
      );
    }

    return null;
  };

  if (gameState.currentActivity) {
    return (
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Activity Header */}
        <Card className="glass-effect border-white/30">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-500 rounded-lg flex items-center justify-center">
                  <gameState.currentActivity.icon className="w-6 h-6 text-white" />
                </div>
                <div>
                  <CardTitle className="gradient-text">{gameState.currentActivity.title}</CardTitle>
                  <CardDescription>{gameState.currentActivity.description}</CardDescription>
                </div>
              </div>
              <Button variant="outline" onClick={resetActivity}>
                <Clock className="w-4 h-4 mr-2" />
                Exit
              </Button>
            </div>
          </CardHeader>
        </Card>

        {/* Game Stats */}
        {gameState.isActive && (
          <div className="grid grid-cols-3 gap-4">
            <Card className="glass-effect border-white/30">
              <CardContent className="p-4 text-center">
                <Timer className="w-6 h-6 mx-auto mb-2 text-purple-600" />
                <p className="text-sm text-muted-foreground">Time</p>
                <p className="text-xl font-bold">{formatTime(gameState.timeRemaining)}</p>
              </CardContent>
            </Card>
            <Card className="glass-effect border-white/30">
              <CardContent className="p-4 text-center">
                <Trophy className="w-6 h-6 mx-auto mb-2 text-yellow-600" />
                <p className="text-sm text-muted-foreground">Score</p>
                <p className="text-xl font-bold">{gameState.score}</p>
              </CardContent>
            </Card>
            <Card className="glass-effect border-white/30">
              <CardContent className="p-4 text-center">
                <Zap className="w-6 h-6 mx-auto mb-2 text-orange-600" />
                <p className="text-sm text-muted-foreground">Streak</p>
                <p className="text-xl font-bold">{gameState.streak}</p>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Activity Content */}
        <Card className="glass-effect border-white/30">
          <CardContent className="p-6">
            {renderActivityContent()}
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-semibold gradient-text">Free Period Activities</h2>
        <p className="text-muted-foreground">Make your free time fun and productive with engaging activities</p>
      </div>

      {/* Category Filter */}
      <div className="flex flex-wrap gap-2">
        {categories.map((category) => {
          const Icon = category.icon;
          return (
            <Button
              key={category.id}
              variant={activeCategory === category.id ? 'default' : 'outline'}
              onClick={() => setActiveCategory(category.id)}
              className={`${
                activeCategory === category.id 
                  ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white' 
                  : 'hover:bg-white/10'
              }`}
            >
              <Icon className="w-4 h-4 mr-2" />
              {category.label}
            </Button>
          );
        })}
      </div>

      {/* Activities Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredActivities.map((activity) => {
          const Icon = activity.icon;
          return (
            <Card 
              key={activity.id}
              className="glass-effect border-white/30 hover:shadow-xl transition-all duration-300 hover:-translate-y-1 cursor-pointer group"
              onClick={() => startActivity(activity)}
            >
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-500 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                    <Icon className="w-6 h-6 text-white" />
                  </div>
                  <Badge variant="outline" className="capitalize">
                    {activity.difficulty}
                  </Badge>
                </div>
                <CardTitle className="group-hover:text-purple-600 transition-colors">{activity.title}</CardTitle>
                <CardDescription className="line-clamp-2">{activity.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between text-sm text-muted-foreground">
                  <div className="flex items-center space-x-1">
                    <Clock className="w-4 h-4" />
                    <span>{activity.duration}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Star className="w-4 h-4 text-yellow-500" />
                    <span>{activity.points} pts</span>
                  </div>
                </div>
                <Button className="w-full mt-4 bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 transition-all duration-300">
                  <PlayCircle className="w-4 h-4 mr-2" />
                  Start Activity
                </Button>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Fun Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="glass-effect border-white/30">
          <CardHeader className="text-center">
            <Trophy className="w-8 h-8 mx-auto text-yellow-500 mb-2" />
            <CardTitle>Today's Points</CardTitle>
          </CardHeader>
          <CardContent className="text-center">
            <div className="text-3xl font-bold gradient-text">0</div>
            <p className="text-sm text-muted-foreground">Start an activity to earn points!</p>
          </CardContent>
        </Card>

        <Card className="glass-effect border-white/30">
          <CardHeader className="text-center">
            <Gamepad2 className="w-8 h-8 mx-auto text-purple-500 mb-2" />
            <CardTitle>Activities Completed</CardTitle>
          </CardHeader>
          <CardContent className="text-center">
            <div className="text-3xl font-bold gradient-text">0</div>
            <p className="text-sm text-muted-foreground">Try your first activity!</p>
          </CardContent>
        </Card>

        <Card className="glass-effect border-white/30">
          <CardHeader className="text-center">
            <Zap className="w-8 h-8 mx-auto text-orange-500 mb-2" />
            <CardTitle>Best Streak</CardTitle>
          </CardHeader>
          <CardContent className="text-center">
            <div className="text-3xl font-bold gradient-text">0</div>
            <p className="text-sm text-muted-foreground">Build your streak!</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}