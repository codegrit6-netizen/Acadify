import React, { useState } from 'react';
import { Button } from '../ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Sheet, SheetContent, SheetTrigger, SheetHeader, SheetTitle, SheetDescription } from '../ui/sheet';
import { 
  Bell, 
  Calendar, 
  Users, 
  BarChart3, 
  QrCode, 
  BookOpen, 
  Settings, 
  LogOut,
  User,
  ClipboardList,
  TrendingUp,
  Info,
  Menu,
  Gamepad2,
  Megaphone,
  Award,
  MessageSquare
} from 'lucide-react';

interface User {
  id: string;
  name: string;
  type: 'student' | 'teacher' | 'admin' | 'parent';
  avatar?: string;
  [key: string]: any; // Allow additional properties
}

interface DashboardLayoutProps {
  user: User;
  onLogout: () => void;
  activeTab: string;
  onTabChange: (tab: string) => void;
  children: React.ReactNode;
}

export function DashboardLayout({ user, onLogout, activeTab, onTabChange, children }: DashboardLayoutProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const getTabsForUserType = () => {
    const commonTabs = [
      { id: 'project-info', label: 'Project Info', icon: Info }
    ];

    let userSpecificTabs = [];
    
    switch (user.type) {
      case 'student':
        userSpecificTabs = [
          { id: 'dashboard', label: 'Dashboard', icon: BarChart3 },
          { id: 'announcements', label: 'Announcements', icon: Megaphone },
          { id: 'ai-chatbot', label: 'AI Study Assistant', icon: MessageSquare },
          { id: 'attendance', label: 'Mark Attendance', icon: QrCode },
          { id: 'study-hub', label: 'Study Hub', icon: Gamepad2 },
          { id: 'calendar', label: 'Activities', icon: Calendar },
          { id: 'reports', label: 'My Reports', icon: ClipboardList },
          { id: 'certificate', label: 'Performance Certificate', icon: Award },
          { id: 'profile', label: 'My Profile', icon: User }
        ];
        break;
      case 'teacher':
        userSpecificTabs = [
          { id: 'dashboard', label: 'Dashboard', icon: BarChart3 },
          { id: 'announcements', label: 'Announcements', icon: Megaphone },
          { id: 'attendance', label: 'Take Attendance', icon: Users },
          { id: 'schedule', label: 'Schedule Class', icon: Calendar },
          { id: 'reports', label: 'Class Reports', icon: TrendingUp },
          { id: 'resources', label: 'Resources', icon: BookOpen }
        ];
        break;
      case 'admin':
        userSpecificTabs = [
          { id: 'dashboard', label: 'Dashboard', icon: BarChart3 },
          { id: 'announcements', label: 'Announcements', icon: Megaphone },
          { id: 'users', label: 'User Management', icon: Users },
          { id: 'reports', label: 'System Reports', icon: TrendingUp },
          { id: 'activities', label: 'Activities', icon: Calendar },
          { id: 'settings', label: 'Settings', icon: Settings }
        ];
        break;
      case 'parent':
        userSpecificTabs = [
          { id: 'dashboard', label: 'Dashboard', icon: BarChart3 },
          { id: 'announcements', label: 'Announcements', icon: Megaphone },
          { id: 'attendance', label: 'Child Attendance', icon: ClipboardList },
          { id: 'activities', label: 'Activities', icon: Calendar },
          { id: 'progress', label: 'Progress', icon: TrendingUp }
        ];
        break;
      default:
        userSpecificTabs = [];
    }

    return [...userSpecificTabs, ...commonTabs];
  };

  const tabs = getTabsForUserType();

  const NavigationContent = () => (
    <Tabs value={activeTab} onValueChange={onTabChange} orientation="vertical" className="w-full">
      <TabsList className="grid w-full grid-cols-1 h-auto bg-transparent p-0 space-y-1">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isProjectInfo = tab.id === 'project-info';
          const isActive = activeTab === tab.id;
          
          return (
            <TabsTrigger
              key={tab.id}
              value={tab.id}
              className={`w-full justify-start px-4 py-3 rounded-lg transition-all duration-300 text-left border ${
                isActive 
                  ? 'bg-gradient-to-r from-indigo-500 to-purple-600 text-white border-indigo-400 shadow-lg transform scale-[1.02]' 
                  : 'bg-transparent border-transparent hover:bg-indigo-50 hover:border-indigo-200 text-slate-700 hover:text-indigo-700'
              } ${isProjectInfo ? 'border-t border-border mt-4 pt-4' : ''}`}
              onClick={() => setMobileMenuOpen(false)}
            >
              <Icon className={`w-4 h-4 mr-3 flex-shrink-0 ${isActive ? 'text-white' : 'text-slate-600'}`} />
              <span className={`font-medium ${isActive ? 'text-white' : 'text-slate-700'}`}>{tab.label}</span>
            </TabsTrigger>
          );
        })}
      </TabsList>
    </Tabs>
  );

  return (
    <div className="min-h-screen bg-background">
      {/* Header - Navy Blue Institutional Style */}
      <header className="institutional-header border-b border-primary-hover shadow-lg sticky top-0 z-50">
        <div className="flex h-16 items-center justify-between px-4 lg:px-6">
          <div className="flex items-center space-x-3 lg:space-x-4">
            {/* Mobile Menu Button */}
            <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="sm" className="lg:hidden text-primary-foreground hover:bg-primary-hover">
                  <Menu className="w-5 h-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-64 p-0 bg-card">
                <SheetHeader className="sr-only">
                  <SheetTitle>Navigation Menu</SheetTitle>
                  <SheetDescription>
                    Navigate through different sections of the Acadify application
                  </SheetDescription>
                </SheetHeader>
                <div className="p-6">
                  <div className="flex items-center space-x-3 mb-6">
                    <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                      <BookOpen className="w-4 h-4 text-primary-foreground" />
                    </div>
                    <h2 className="text-primary font-semibold">Navigation</h2>
                  </div>
                  <NavigationContent />
                </div>
              </SheetContent>
            </Sheet>

            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 lg:w-10 lg:h-10 bg-white/20 rounded-xl flex items-center justify-center backdrop-blur">
                <BookOpen className="w-4 h-4 lg:w-5 lg:h-5 text-white" />
              </div>
              <h1 className="text-lg lg:text-xl font-semibold text-white">Acadify</h1>
            </div>
            <div className="px-3 py-1 bg-accent rounded-full">
              <span className="capitalize text-xs lg:text-sm font-medium text-accent-foreground">
                {user.type}
              </span>
            </div>
          </div>
          
          <div className="flex items-center space-x-2 lg:space-x-3">
            <Button variant="ghost" size="sm" className="relative text-primary-foreground hover:bg-primary-hover">
              <Bell className="w-4 h-4" />
              <span className="absolute -top-1 -right-1 w-2 h-2 bg-accent rounded-full"></span>
            </Button>
            <div className="hidden sm:flex items-center space-x-3 pl-3 border-l border-white/20">
              <div className="w-7 h-7 lg:w-8 lg:h-8 bg-white/20 rounded-full flex items-center justify-center backdrop-blur">
                <User className="w-3 h-3 lg:w-4 lg:h-4 text-white" />
              </div>
              <span className="text-sm font-medium text-white truncate max-w-24 lg:max-w-none">
                {user.name}
              </span>
            </div>
            <Button variant="ghost" size="sm" onClick={onLogout} className="text-primary-foreground hover:bg-primary-hover">
              <LogOut className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="flex min-h-[calc(100vh-4rem)]">
        {/* Desktop Sidebar Navigation */}
        <nav className="hidden lg:block w-64 border-r border-border bg-card shadow-sm">
          <div className="p-6">
            <NavigationContent />
          </div>
        </nav>

        {/* Content Area */}
        <main className="flex-1 p-4 lg:p-6 bg-background">
          <div className="max-w-full">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}