import React, { useState, useRef, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Badge } from '../ui/badge';
import { ScrollArea } from '../ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Textarea } from '../ui/textarea';
import { Checkbox } from '../ui/checkbox';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { getUserById } from '../../data/mockDatabase';
import type { Student } from '../../data/mockDatabase';
import { 
  Bot, 
  Send, 
  User, 
  Plus,
  CheckCircle,
  Clock,
  Trash2,
  BookOpen,
  Calendar,
  Target,
  Lightbulb,
  MessageSquare,
  ListTodo,
  Star,
  Coffee,
  Zap,
  Heart,
  Brain
} from 'lucide-react';

interface AIStudentChatbotProps {
  studentId: string;
}

interface ChatMessage {
  id: string;
  type: 'user' | 'ai';
  content: string;
  timestamp: Date;
  category?: 'general' | 'study' | 'assignment' | 'todo' | 'planning';
}

interface TodoItem {
  id: string;
  text: string;
  completed: boolean;
  priority: 'low' | 'medium' | 'high';
  dueDate?: string;
  subject?: string;
  createdAt: Date;
}

const chatbotResponses = {
  greeting: [
    "Hello! I'm your personal AI study assistant. How can I help you today?",
    "Hi there! Ready to tackle your studies? What would you like to work on?",
    "Hey! I'm here to help you succeed. What's on your mind?",
  ],
  study: [
    "Great question! Let me help you with that study topic.",
    "I'd be happy to help you understand this better.",
    "Let's break this down step by step.",
  ],
  assignment: [
    "I can definitely help you with your assignment planning.",
    "Let's organize your assignment tasks effectively.",
    "Here's how I suggest approaching this assignment:",
  ],
  todo: [
    "I've added that to your to-do list!",
    "Task added! Don't forget to set a priority level.",
    "Perfect! I'll help you stay on track with this task.",
  ],
  motivation: [
    "You're doing great! Keep up the excellent work! 🌟",
    "Every step forward is progress. I believe in you! 💪",
    "Remember, consistent effort leads to amazing results! ✨",
    "You've got this! Stay focused and keep pushing forward! 🚀",
  ],
  planning: [
    "Let's create a study plan that works for you.",
    "Planning is key to success. Here's what I recommend:",
    "Smart planning leads to better results. Let's organize your schedule.",
  ]
};

const studyTips = [
  {
    title: "Pomodoro Technique",
    description: "Study for 25 minutes, then take a 5-minute break",
    icon: <Clock className="h-4 w-4" />
  },
  {
    title: "Active Recall",
    description: "Test yourself regularly instead of just re-reading",
    icon: <Brain className="h-4 w-4" />
  },
  {
    title: "Study Environment",
    description: "Find a quiet, organized space dedicated to learning",
    icon: <BookOpen className="h-4 w-4" />
  },
  {
    title: "Goal Setting",
    description: "Break large tasks into smaller, manageable goals",
    icon: <Target className="h-4 w-4" />
  }
];

export function AIStudentChatbot({ studentId }: AIStudentChatbotProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputMessage, setInputMessage] = useState('');
  const [todos, setTodos] = useState<TodoItem[]>([]);
  const [newTodo, setNewTodo] = useState('');
  const [newTodoPriority, setNewTodoPriority] = useState<'low' | 'medium' | 'high'>('medium');
  const [newTodoSubject, setNewTodoSubject] = useState('');
  const [newTodoDueDate, setNewTodoDueDate] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  const student = getUserById(studentId, 'student') as Student;

  useEffect(() => {
    // Initial greeting message
    const greeting: ChatMessage = {
      id: '1',
      type: 'ai',
      content: `Hi ${student?.name || 'there'}! I'm your personal AI study assistant. I can help you with study questions, manage your to-do list, plan your assignments, and provide study tips. What would you like to work on today?`,
      timestamp: new Date(),
      category: 'general'
    };
    setMessages([greeting]);

    // Sample todos
    setTodos([
      {
        id: '1',
        text: 'Complete Math Assignment Chapter 5',
        completed: false,
        priority: 'high',
        subject: 'Mathematics',
        dueDate: '2024-09-15',
        createdAt: new Date()
      },
      {
        id: '2',
        text: 'Review Physics notes for upcoming test',
        completed: false,
        priority: 'medium',
        subject: 'Physics',
        dueDate: '2024-09-12',
        createdAt: new Date()
      },
      {
        id: '3',
        text: 'Prepare presentation slides',
        completed: true,
        priority: 'medium',
        subject: 'English',
        createdAt: new Date()
      }
    ]);
  }, [student]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const generateAIResponse = (userMessage: string): string => {
    const message = userMessage.toLowerCase();
    
    // Personalized responses based on student data
    if (message.includes('grade') || message.includes('marks')) {
      if (student?.grades?.length > 0) {
        const avgGrade = student.grades.reduce((sum, g) => sum + g.marks, 0) / student.grades.length;
        return `Based on your current grades, your average is ${avgGrade.toFixed(1)}%. ${avgGrade >= 80 ? 'Great work! Keep it up!' : 'There\'s room for improvement. Would you like some study tips to boost your performance?'}`;
      }
    }
    
    if (message.includes('attendance')) {
      if (student?.attendanceStats) {
        return `Your current attendance rate is ${student.attendanceStats.percentage}%. ${student.attendanceStats.percentage >= 85 ? 'Excellent attendance! This really helps with learning.' : 'Try to improve your attendance - it makes a big difference in understanding concepts.'}`;
      }
    }
    
    if (message.includes('subject') && student?.subjects) {
      return `You're enrolled in ${student.subjects.length} subjects: ${student.subjects.slice(0, 3).join(', ')}${student.subjects.length > 3 ? ' and more' : ''}. Which subject would you like help with?`;
    }
    
    if (message.includes('todo') || message.includes('task')) {
      return chatbotResponses.todo[Math.floor(Math.random() * chatbotResponses.todo.length)];
    }
    
    if (message.includes('study') || message.includes('learn')) {
      return chatbotResponses.study[Math.floor(Math.random() * chatbotResponses.study.length)] + " I can suggest study techniques, help you understand concepts, or create a study schedule.";
    }
    
    if (message.includes('assignment') || message.includes('homework')) {
      return chatbotResponses.assignment[Math.floor(Math.random() * chatbotResponses.assignment.length)] + " Break it down into smaller tasks and set deadlines for each part.";
    }
    
    if (message.includes('plan') || message.includes('schedule')) {
      return chatbotResponses.planning[Math.floor(Math.random() * chatbotResponses.planning.length)];
    }
    
    if (message.includes('stress') || message.includes('overwhelm') || message.includes('difficult')) {
      return "I understand studying can be challenging sometimes. Remember to take breaks, stay organized, and ask for help when needed. You're capable of great things! 💪";
    }
    
    if (message.includes('motivation') || message.includes('encourage')) {
      return chatbotResponses.motivation[Math.floor(Math.random() * chatbotResponses.motivation.length)];
    }
    
    // Default helpful response
    return "I'm here to help! I can assist with study questions, manage your to-do list, provide study tips, help plan assignments, or just chat about your academic goals. What specific area would you like help with?";
  };

  const handleSendMessage = async () => {
    if (!inputMessage.trim()) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      type: 'user',
      content: inputMessage,
      timestamp: new Date(),
      category: 'general'
    };

    setMessages(prev => [...prev, userMessage]);
    setInputMessage('');
    setIsTyping(true);

    // Simulate AI thinking time
    setTimeout(() => {
      const aiResponse: ChatMessage = {
        id: (Date.now() + 1).toString(),
        type: 'ai',
        content: generateAIResponse(inputMessage),
        timestamp: new Date(),
        category: 'general'
      };
      
      setMessages(prev => [...prev, aiResponse]);
      setIsTyping(false);
    }, 1000 + Math.random() * 1000);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const addTodo = () => {
    if (!newTodo.trim()) return;

    const todo: TodoItem = {
      id: Date.now().toString(),
      text: newTodo,
      completed: false,
      priority: newTodoPriority,
      subject: newTodoSubject || undefined,
      dueDate: newTodoDueDate || undefined,
      createdAt: new Date()
    };

    setTodos(prev => [...prev, todo]);
    setNewTodo('');
    setNewTodoSubject('');
    setNewTodoDueDate('');

    // Add AI response
    const aiMessage: ChatMessage = {
      id: Date.now().toString(),
      type: 'ai',
      content: `Perfect! I've added "${newTodo}" to your to-do list with ${newTodoPriority} priority. ${newTodoDueDate ? `Don't forget it's due on ${newTodoDueDate}!` : 'Remember to set a deadline to stay on track!'}`,
      timestamp: new Date(),
      category: 'todo'
    };
    setMessages(prev => [...prev, aiMessage]);
  };

  const toggleTodo = (id: string) => {
    setTodos(prev => prev.map(todo => 
      todo.id === id ? { ...todo, completed: !todo.completed } : todo
    ));
  };

  const deleteTodo = (id: string) => {
    setTodos(prev => prev.filter(todo => todo.id !== id));
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'text-red-600 bg-red-50 border-red-200';
      case 'medium': return 'text-yellow-600 bg-yellow-50 border-yellow-200';
      case 'low': return 'text-green-600 bg-green-50 border-green-200';
      default: return 'text-gray-600 bg-gray-50 border-gray-200';
    }
  };

  const quickActions = [
    { text: "Help me study for my next exam", icon: <BookOpen className="h-4 w-4" /> },
    { text: "Create a study schedule", icon: <Calendar className="h-4 w-4" /> },
    { text: "Give me study tips", icon: <Lightbulb className="h-4 w-4" /> },
    { text: "How can I improve my grades?", icon: <Target className="h-4 w-4" /> }
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <div className="p-2 bg-gradient-to-r from-purple-500 to-indigo-500 rounded-lg">
          <Bot className="h-6 w-6 text-white" />
        </div>
        <div>
          <h2 className="text-xl font-semibold">AI Study Assistant</h2>
          <p className="text-sm text-muted-foreground">
            Your personalized learning companion
          </p>
        </div>
      </div>

      <Tabs defaultValue="chat" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="chat" className="gap-2">
            <MessageSquare className="h-4 w-4" />
            Chat
          </TabsTrigger>
          <TabsTrigger value="todos" className="gap-2">
            <ListTodo className="h-4 w-4" />
            To-Do List
          </TabsTrigger>
          <TabsTrigger value="tips" className="gap-2">
            <Lightbulb className="h-4 w-4" />
            Study Tips
          </TabsTrigger>
        </TabsList>

        <TabsContent value="chat" className="space-y-4">
          <Card className="professional-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-primary">
                <Bot className="h-5 w-5" />
                Chat with AI Assistant
              </CardTitle>
              <CardDescription>
                Ask questions, get study help, or manage your tasks
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {/* Chat Messages */}
                <ScrollArea className="h-96 w-full border rounded-lg p-4">
                  <div className="space-y-4">
                    {messages.map((message) => (
                      <div
                        key={message.id}
                        className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
                      >
                        <div className={`flex max-w-[80%] gap-2 ${message.type === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
                          <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                            message.type === 'user' ? 'bg-primary' : 'bg-gradient-to-r from-purple-500 to-indigo-500'
                          }`}>
                            {message.type === 'user' ? (
                              <User className="h-4 w-4 text-white" />
                            ) : (
                              <Bot className="h-4 w-4 text-white" />
                            )}
                          </div>
                          <div className={`rounded-lg p-3 ${
                            message.type === 'user' 
                              ? 'bg-primary text-primary-foreground' 
                              : 'bg-secondary text-secondary-foreground border'
                          }`}>
                            <p className="text-sm">{message.content}</p>
                            <p className="text-xs opacity-70 mt-1">
                              {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </p>
                          </div>
                        </div>
                      </div>
                    ))}
                    {isTyping && (
                      <div className="flex justify-start">
                        <div className="flex gap-2">
                          <div className="w-8 h-8 rounded-full flex items-center justify-center bg-gradient-to-r from-purple-500 to-indigo-500">
                            <Bot className="h-4 w-4 text-white" />
                          </div>
                          <div className="bg-secondary border rounded-lg p-3">
                            <div className="flex space-x-1">
                              <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce"></div>
                              <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                              <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}
                    <div ref={messagesEndRef} />
                  </div>
                </ScrollArea>

                {/* Quick Action Buttons */}
                <div className="grid grid-cols-2 gap-2">
                  {quickActions.map((action, index) => (
                    <Button
                      key={index}
                      variant="outline"
                      size="sm"
                      onClick={() => setInputMessage(action.text)}
                      className="justify-start gap-2"
                    >
                      {action.icon}
                      {action.text}
                    </Button>
                  ))}
                </div>

                {/* Message Input */}
                <div className="flex space-x-2">
                  <Input
                    value={inputMessage}
                    onChange={(e) => setInputMessage(e.target.value)}
                    onKeyPress={handleKeyPress}
                    placeholder="Ask me anything about your studies..."
                    className="flex-1"
                  />
                  <Button onClick={handleSendMessage} className="btn-primary gap-2">
                    <Send className="h-4 w-4" />
                    Send
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="todos" className="space-y-4">
          <Card className="professional-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-primary">
                <ListTodo className="h-5 w-5" />
                My To-Do List
              </CardTitle>
              <CardDescription>
                Keep track of your assignments and tasks
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {/* Add New Todo */}
                <div className="space-y-3 p-4 bg-secondary/30 rounded-lg border">
                  <div className="flex items-center gap-2">
                    <Plus className="h-4 w-4 text-primary" />
                    <h4 className="font-medium">Add New Task</h4>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <Input
                      value={newTodo}
                      onChange={(e) => setNewTodo(e.target.value)}
                      placeholder="Enter task description..."
                      className="md:col-span-2"
                    />
                    <Select value={newTodoPriority} onValueChange={(value: 'low' | 'medium' | 'high') => setNewTodoPriority(value)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">Low Priority</SelectItem>
                        <SelectItem value="medium">Medium Priority</SelectItem>
                        <SelectItem value="high">High Priority</SelectItem>
                      </SelectContent>
                    </Select>
                    <Input
                      type="date"
                      value={newTodoDueDate}
                      onChange={(e) => setNewTodoDueDate(e.target.value)}
                      placeholder="Due date (optional)"
                    />
                    <Input
                      value={newTodoSubject}
                      onChange={(e) => setNewTodoSubject(e.target.value)}
                      placeholder="Subject (optional)"
                    />
                    <Button onClick={addTodo} className="btn-accent gap-2">
                      <Plus className="h-4 w-4" />
                      Add Task
                    </Button>
                  </div>
                </div>

                {/* Todo List */}
                <div className="space-y-3">
                  {todos.length === 0 ? (
                    <div className="text-center py-8 text-muted-foreground">
                      <ListTodo className="h-8 w-8 mx-auto mb-2 opacity-50" />
                      <p>No tasks yet. Add your first task above!</p>
                    </div>
                  ) : (
                    todos.map((todo) => (
                      <div
                        key={todo.id}
                        className={`flex items-center space-x-3 p-3 border rounded-lg transition-all ${
                          todo.completed ? 'bg-muted/30 opacity-75' : 'bg-background hover:shadow-sm'
                        }`}
                      >
                        <Checkbox
                          checked={todo.completed}
                          onCheckedChange={() => toggleTodo(todo.id)}
                        />
                        <div className="flex-1">
                          <p className={`font-medium ${todo.completed ? 'line-through text-muted-foreground' : ''}`}>
                            {todo.text}
                          </p>
                          <div className="flex items-center gap-2 mt-1">
                            <Badge
                              variant="outline"
                              className={`text-xs ${getPriorityColor(todo.priority)}`}
                            >
                              {todo.priority} priority
                            </Badge>
                            {todo.subject && (
                              <Badge variant="outline" className="text-xs">
                                {todo.subject}
                              </Badge>
                            )}
                            {todo.dueDate && (
                              <div className="flex items-center gap-1 text-xs text-muted-foreground">
                                <Calendar className="h-3 w-3" />
                                {todo.dueDate}
                              </div>
                            )}
                          </div>
                        </div>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => deleteTodo(todo.id)}
                          className="text-destructive hover:text-destructive"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    ))
                  )}
                </div>

                {/* Todo Stats */}
                {todos.length > 0 && (
                  <div className="grid grid-cols-3 gap-4 pt-4 border-t">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-primary">{todos.length}</div>
                      <p className="text-xs text-muted-foreground">Total Tasks</p>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-green-600">
                        {todos.filter(t => t.completed).length}
                      </div>
                      <p className="text-xs text-muted-foreground">Completed</p>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-orange-600">
                        {todos.filter(t => !t.completed).length}
                      </div>
                      <p className="text-xs text-muted-foreground">Remaining</p>
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="tips" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {studyTips.map((tip, index) => (
              <Card key={index} className="professional-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-primary">
                    {tip.icon}
                    {tip.title}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">{tip.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>

          <Card className="professional-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-primary">
                <Star className="h-5 w-5" />
                Personalized Study Recommendations
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {student?.attendanceStats?.percentage && student.attendanceStats.percentage < 85 && (
                <div className="p-3 bg-orange-50 border border-orange-200 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <Clock className="h-4 w-4 text-orange-600" />
                    <span className="font-medium text-orange-800">Attendance Focus</span>
                  </div>
                  <p className="text-sm text-orange-700">
                    Your attendance is at {student.attendanceStats.percentage}%. Try to attend classes regularly to improve understanding and grades.
                  </p>
                </div>
              )}
              
              {student?.grades && student.grades.some(g => g.marks < 70) && (
                <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <Brain className="h-4 w-4 text-blue-600" />
                    <span className="font-medium text-blue-800">Study Improvement</span>
                  </div>
                  <p className="text-sm text-blue-700">
                    Some subjects need extra attention. Consider spending more time on challenging topics and asking for help when needed.
                  </p>
                </div>
              )}
              
              <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <Heart className="h-4 w-4 text-green-600" />
                  <span className="font-medium text-green-800">Daily Motivation</span>
                </div>
                <p className="text-sm text-green-700">
                  "Success is the sum of small efforts repeated day in and day out." - Keep going, you're doing great!
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}