import React, { useState, useMemo } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../ui/table';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { Alert, AlertDescription, AlertTitle } from '../ui/alert';
import { Progress } from '../ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { students, getTeacherStudents, getStudentAssignments, attendanceRecords } from '../../data/mockDatabase';
import type { Student } from '../../data/mockDatabase';
import { 
  Brain, 
  AlertTriangle, 
  TrendingDown, 
  TrendingUp,
  Users,
  Target,
  BookOpen,
  Clock,
  Award,
  MessageSquare,
  Send,
  Filter,
  Search,
  BarChart3,
  Lightbulb,
  Shield,
  Eye
} from 'lucide-react';

interface AIPerformancePredictorProps {
  userType: 'admin' | 'teacher';
  userId: string;
}

interface RiskAnalysis {
  studentId: string;
  student: Student;
  overallRiskScore: number;
  riskLevel: 'Low' | 'Medium' | 'High' | 'Critical';
  riskFactors: {
    attendance: number;
    academicPerformance: number;
    trendAnalysis: number;
    subjectConsistency: number;
  };
  predictions: {
    dropoutRisk: number;
    backlogRisk: number;
    lowGradeRisk: number;
  };
  recommendations: string[];
  alerts: {
    type: 'warning' | 'danger' | 'info';
    message: string;
    priority: 'low' | 'medium' | 'high' | 'urgent';
  }[];
}

export function AIPerformancePredictor({ userType, userId }: AIPerformancePredictorProps) {
  const [selectedRiskLevel, setSelectedRiskLevel] = useState<string>('all');
  const [selectedStudent, setSelectedStudent] = useState<string>('');
  const [searchQuery, setSearchQuery] = useState('');
  const [showAlertDialog, setShowAlertDialog] = useState(false);
  const [selectedAlerts, setSelectedAlerts] = useState<RiskAnalysis[]>([]);
  const [error, setError] = useState<string | null>(null);

  // Error boundary wrapper
  React.useEffect(() => {
    const handleError = (error: ErrorEvent) => {
      setError('An error occurred while loading the AI Performance Predictor');
      console.error('AI Performance Predictor Error:', error);
    };

    window.addEventListener('error', handleError);
    return () => window.removeEventListener('error', handleError);
  }, []);

  // Get students based on user type
  const relevantStudents = useMemo(() => {
    if (userType === 'admin') {
      return students;
    } else {
      return getTeacherStudents(userId) || [];
    }
  }, [userType, userId]);

  // AI Risk Analysis Algorithm
  const calculateRiskAnalysis = (student: Student): RiskAnalysis => {
    // Safety checks for student data
    if (!student || !student.attendanceStats || !student.grades) {
      return {
        studentId: student?.id || 'unknown',
        student: student,
        overallRiskScore: 0,
        riskLevel: 'Low',
        riskFactors: {
          attendance: 0,
          academicPerformance: 0,
          trendAnalysis: 0,
          subjectConsistency: 0
        },
        predictions: {
          dropoutRisk: 0,
          backlogRisk: 0,
          lowGradeRisk: 0
        },
        recommendations: [],
        alerts: []
      };
    }

    // Attendance Risk Factor (0-100, higher = more risk)
    const attendanceRisk = Math.max(0, 100 - (student.attendanceStats?.percentage || 85));
    
    // Recent attendance pattern analysis
    const recentAttendance = attendanceRecords
      .filter(record => record.studentId === student.id)
      .slice(-10); // Last 10 records
    const recentAbsentCount = recentAttendance.filter(r => r.status === 'absent').length;
    const recentAttendanceRisk = (recentAbsentCount / Math.max(1, recentAttendance.length)) * 100;
    
    // Academic Performance Risk Factor
    const grades = student.grades || [];
    const avgMarks = grades.length > 0 ? 
      grades.reduce((sum, grade) => sum + (grade.marks || 0), 0) / grades.length : 75;
    const academicRisk = Math.max(0, 100 - (avgMarks / 100 * 100));
    
    // Assignment submission analysis
    const studentAssignments = getStudentAssignments(student.id) || [];
    const assignmentRisk = studentAssignments.length > 0 ? 
      studentAssignments.reduce((risk, { assignment, submission }) => {
        if (!submission || submission.status === 'pending') return risk + 30;
        if (submission.status === 'late') return risk + 15;
        if (submission.marks && submission.marks < (assignment.maxMarks || 100) * 0.6) return risk + 10;
        return risk;
      }, 0) / studentAssignments.length : 0;
    
    // Subject Consistency Risk (variance in grades)
    const marksVariance = student.grades.reduce((sum, grade) => 
      sum + Math.pow(grade.marks - avgMarks, 2), 0) / student.grades.length;
    const consistencyRisk = Math.min(100, Math.sqrt(marksVariance) * 2);
    
    // Trend Analysis (enhanced with assignment and attendance patterns)
    const trendRisk = Math.min(100, 
      (student.semester > 2 && avgMarks < 80 ? Math.max(0, (4 - student.semester) * 15 + (80 - avgMarks)) : 0) +
      (recentAttendanceRisk > 30 ? 20 : 0) +
      (assignmentRisk > 20 ? 15 : 0)
    );
    
    // Calculate overall risk score with enhanced factors
    const overallRisk = (
      attendanceRisk * 0.25 + 
      recentAttendanceRisk * 0.15 +
      academicRisk * 0.25 + 
      assignmentRisk * 0.15 +
      consistencyRisk * 0.10 + 
      trendRisk * 0.10
    );
    
    // Determine risk level
    let riskLevel: RiskAnalysis['riskLevel'];
    if (overallRisk < 25) riskLevel = 'Low';
    else if (overallRisk < 50) riskLevel = 'Medium';
    else if (overallRisk < 75) riskLevel = 'High';
    else riskLevel = 'Critical';
    
    // Calculate specific predictions
    const dropoutRisk = Math.min(100, overallRisk * 0.8 + (attendanceRisk > 40 ? 20 : 0));
    const backlogRisk = Math.min(100, academicRisk * 1.2 + consistencyRisk * 0.8);
    const lowGradeRisk = Math.min(100, academicRisk * 1.1 + trendRisk * 0.9);
    
    // Generate recommendations
    const recommendations: string[] = [];
    if (attendanceRisk > 30 || recentAttendanceRisk > 30) {
      recommendations.push("Implement personalized attendance improvement plan");
      recommendations.push("Schedule regular check-ins with student");
      recommendations.push("Contact parent/guardian about attendance concerns");
    }
    if (academicRisk > 25) {
      recommendations.push("Provide additional academic support and tutoring");
      recommendations.push("Consider peer mentoring program");
      recommendations.push("Schedule one-on-one academic coaching sessions");
    }
    if (assignmentRisk > 20) {
      recommendations.push("Implement assignment tracking and reminder system");
      recommendations.push("Provide time management and study skills training");
      recommendations.push("Create structured homework support program");
    }
    if (consistencyRisk > 30) {
      recommendations.push("Focus on weaker subjects with targeted interventions");
      recommendations.push("Develop subject-specific study strategies");
      recommendations.push("Analyze learning style and adapt teaching methods");
    }
    if (trendRisk > 20) {
      recommendations.push("Immediate counseling session recommended");
      recommendations.push("Review and adjust academic goals");
      recommendations.push("Consider academic probation or intensive support program");
    }
    
    // Generate alerts
    const alerts: RiskAnalysis['alerts'] = [];
    if (overallRisk > 70) {
      alerts.push({
        type: 'danger',
        message: `${student.name} is at critical risk of academic failure`,
        priority: 'urgent'
      });
    }
    if (attendanceRisk > 50) {
      alerts.push({
        type: 'warning',
        message: `${student.name} has concerning attendance patterns (${student.attendanceStats.percentage}%)`,
        priority: 'high'
      });
    }
    if (dropoutRisk > 60) {
      alerts.push({
        type: 'danger',
        message: `${student.name} shows high dropout risk indicators`,
        priority: 'urgent'
      });
    }
    if (backlogRisk > 50) {
      alerts.push({
        type: 'warning',
        message: `${student.name} may face subject backlogs`,
        priority: 'medium'
      });
    }
    if (assignmentRisk > 30) {
      alerts.push({
        type: 'warning',
        message: `${student.name} has poor assignment submission patterns`,
        priority: 'medium'
      });
    }
    if (recentAttendanceRisk > 40) {
      alerts.push({
        type: 'danger',
        message: `${student.name} shows declining attendance in recent classes`,
        priority: 'high'
      });
    }
    
    return {
      studentId: student.id,
      student,
      overallRiskScore: Math.round(overallRisk),
      riskLevel,
      riskFactors: {
        attendance: Math.round((attendanceRisk + recentAttendanceRisk) / 2),
        academicPerformance: Math.round((academicRisk + assignmentRisk) / 2),
        trendAnalysis: Math.round(trendRisk),
        subjectConsistency: Math.round(consistencyRisk)
      },
      predictions: {
        dropoutRisk: Math.round(dropoutRisk),
        backlogRisk: Math.round(backlogRisk),
        lowGradeRisk: Math.round(lowGradeRisk)
      },
      recommendations,
      alerts
    };
  };

  // Calculate risk analysis for all relevant students
  const riskAnalyses = useMemo(() => {
    return relevantStudents.map(calculateRiskAnalysis)
      .sort((a, b) => b.overallRiskScore - a.overallRiskScore);
  }, [relevantStudents]);

  // Filter analyses based on selected criteria
  const filteredAnalyses = useMemo(() => {
    return riskAnalyses.filter(analysis => {
      const matchesRiskLevel = selectedRiskLevel === 'all' || 
        analysis.riskLevel.toLowerCase() === selectedRiskLevel.toLowerCase();
      const matchesSearch = analysis.student.name.toLowerCase()
        .includes(searchQuery.toLowerCase()) ||
        analysis.student.rollNumber.toLowerCase()
        .includes(searchQuery.toLowerCase());
      const matchesStudent = !selectedStudent || analysis.studentId === selectedStudent;
      
      return matchesRiskLevel && matchesSearch && matchesStudent;
    });
  }, [riskAnalyses, selectedRiskLevel, searchQuery, selectedStudent]);

  // Calculate summary statistics
  const summaryStats = useMemo(() => {
    const total = riskAnalyses.length;
    const critical = riskAnalyses.filter(a => a.riskLevel === 'Critical').length;
    const high = riskAnalyses.filter(a => a.riskLevel === 'High').length;
    const medium = riskAnalyses.filter(a => a.riskLevel === 'Medium').length;
    const low = riskAnalyses.filter(a => a.riskLevel === 'Low').length;
    const avgRiskScore = riskAnalyses.reduce((sum, a) => sum + a.overallRiskScore, 0) / total;
    
    return { total, critical, high, medium, low, avgRiskScore: Math.round(avgRiskScore) };
  }, [riskAnalyses]);

  // Get all active alerts
  const allAlerts = useMemo(() => {
    return riskAnalyses.reduce((acc, analysis) => {
      return acc.concat(analysis.alerts.map(alert => ({ ...alert, student: analysis.student })));
    }, [] as Array<RiskAnalysis['alerts'][0] & { student: Student }>)
      .sort((a, b) => {
        const priorityOrder = { urgent: 4, high: 3, medium: 2, low: 1 };
        return priorityOrder[b.priority] - priorityOrder[a.priority];
      });
  }, [riskAnalyses]);

  const getRiskLevelColor = (level: string) => {
    switch (level) {
      case 'Critical': return 'destructive';
      case 'High': return 'destructive';
      case 'Medium': return 'secondary';
      case 'Low': return 'secondary';
      default: return 'secondary';
    }
  };

  const getRiskLevelBg = (level: string) => {
    switch (level) {
      case 'Critical': return 'bg-red-50 border-red-200';
      case 'High': return 'bg-orange-50 border-orange-200';
      case 'Medium': return 'bg-yellow-50 border-yellow-200';
      case 'Low': return 'bg-green-50 border-green-200';
      default: return 'bg-gray-50 border-gray-200';
    }
  };

  const sendAlert = (analyses: RiskAnalysis[]) => {
    // In a real app, this would send notifications to parents/teachers/admins
    const alertCount = analyses.reduce((sum, a) => sum + a.alerts.length, 0);
    alert(`${alertCount} alerts have been sent to relevant stakeholders for ${analyses.length} students.`);
    setShowAlertDialog(false);
  };

  // Display error state if there's an error
  if (error) {
    return (
      <div className="space-y-6">
        <Card className="border-red-200 bg-red-50">
          <CardHeader>
            <CardTitle className="text-red-800 flex items-center gap-2">
              <AlertTriangle className="h-5 w-5" />
              AI Performance Predictor Error
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-red-700">{error}</p>
            <Button 
              onClick={() => setError(null)} 
              variant="outline" 
              className="mt-4"
            >
              Try Again
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  try {
    return (
      <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-gradient-to-r from-purple-500 to-indigo-500 rounded-lg">
            <Brain className="h-6 w-6 text-white" />
          </div>
          <div>
            <h2 className="text-xl font-semibold">AI Performance Predictor</h2>
            <p className="text-sm text-muted-foreground">
              Intelligent early warning system for student risk assessment
            </p>
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          <Dialog open={showAlertDialog} onOpenChange={setShowAlertDialog}>
            <DialogTrigger asChild>
              <Button variant="outline" className="gap-2">
                <MessageSquare className="h-4 w-4" />
                Send Alerts ({allAlerts.length})
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Send Risk Alerts</DialogTitle>
                <DialogDescription>
                  Send notifications to parents, teachers, and administrators about at-risk students
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 max-h-96 overflow-y-auto">
                {allAlerts.slice(0, 10).map((alert, index) => (
                  <Alert key={index} className={alert.type === 'danger' ? 'border-red-200' : 'border-yellow-200'}>
                    <AlertTriangle className="h-4 w-4" />
                    <AlertTitle className="flex items-center justify-between">
                      {alert.student.name}
                      <Badge variant={alert.priority === 'urgent' ? 'destructive' : 'secondary'}>
                        {alert.priority}
                      </Badge>
                    </AlertTitle>
                    <AlertDescription>{alert.message}</AlertDescription>
                  </Alert>
                ))}
              </div>
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setShowAlertDialog(false)}>
                  Cancel
                </Button>
                <Button onClick={() => sendAlert(filteredAnalyses)} className="gap-2">
                  <Send className="h-4 w-4" />
                  Send Alerts
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Summary Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Total Students</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{summaryStats.total}</div>
            <p className="text-xs text-muted-foreground">Under AI monitoring</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">High Risk</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">
              {summaryStats.critical + summaryStats.high}
            </div>
            <p className="text-xs text-muted-foreground">Require immediate attention</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Average Risk Score</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{summaryStats.avgRiskScore}%</div>
            <p className="text-xs text-muted-foreground">
              {summaryStats.avgRiskScore < 25 ? 'Low' : 
               summaryStats.avgRiskScore < 50 ? 'Medium' : 'High'} overall risk
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Active Alerts</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">{allAlerts.length}</div>
            <p className="text-xs text-muted-foreground">Pending notifications</p>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Filters & Search</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <Label htmlFor="search">Search Students</Label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  id="search"
                  placeholder="Search by name or roll number..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            
            <div className="w-full sm:w-48">
              <Label htmlFor="risk-level">Risk Level</Label>
              <Select value={selectedRiskLevel} onValueChange={setSelectedRiskLevel}>
                <SelectTrigger>
                  <SelectValue placeholder="All Risk Levels" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Risk Levels</SelectItem>
                  <SelectItem value="critical">Critical</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="low">Low</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="w-full sm:w-48">
              <Label htmlFor="student">Specific Student</Label>
              <Select value={selectedStudent} onValueChange={setSelectedStudent}>
                <SelectTrigger>
                  <SelectValue placeholder="All Students" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">All Students</SelectItem>
                  {relevantStudents.map(student => (
                    <SelectItem key={student.id} value={student.id}>
                      {student.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Risk Analysis Table */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5" />
            Student Risk Analysis
          </CardTitle>
          <CardDescription>
            AI-powered assessment showing risk factors and predictions for each student
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Student</TableHead>
                  <TableHead>Risk Level</TableHead>
                  <TableHead>Overall Score</TableHead>
                  <TableHead>Attendance Risk</TableHead>
                  <TableHead>Academic Risk</TableHead>
                  <TableHead>Predictions</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredAnalyses.map((analysis) => (
                  <TableRow key={analysis.studentId} className={getRiskLevelBg(analysis.riskLevel)}>
                    <TableCell>
                      <div>
                        <div className="font-medium">{analysis.student.name}</div>
                        <div className="text-sm text-muted-foreground">
                          {analysis.student.rollNumber} • {analysis.student.class}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant={getRiskLevelColor(analysis.riskLevel) as any}>
                        {analysis.riskLevel}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Progress value={analysis.overallRiskScore} className="w-16" />
                        <span className="text-sm font-medium">{analysis.overallRiskScore}%</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="text-sm">
                        {analysis.riskFactors.attendance}% risk
                        <div className="text-xs text-muted-foreground">
                          ({analysis.student.attendanceStats.percentage}% attendance)
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="text-sm">
                        {analysis.riskFactors.academicPerformance}% risk
                        <div className="text-xs text-muted-foreground">
                          (Avg: {Math.round(analysis.student.grades.reduce((sum, g) => sum + g.marks, 0) / analysis.student.grades.length)}%)
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="space-y-1">
                        <div className="text-xs">
                          <span className="text-muted-foreground">Dropout:</span> {analysis.predictions.dropoutRisk}%
                        </div>
                        <div className="text-xs">
                          <span className="text-muted-foreground">Backlog:</span> {analysis.predictions.backlogRisk}%
                        </div>
                        <div className="text-xs">
                          <span className="text-muted-foreground">Low Grade:</span> {analysis.predictions.lowGradeRisk}%
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button variant="outline" size="sm" className="gap-2">
                            <Eye className="h-4 w-4" />
                            View Details
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
                          <DialogHeader>
                            <DialogTitle className="flex items-center gap-2">
                              <Brain className="h-5 w-5" />
                              AI Analysis: {analysis.student.name}
                            </DialogTitle>
                            <DialogDescription>
                              Comprehensive risk assessment and recommendations
                            </DialogDescription>
                          </DialogHeader>
                          
                          <Tabs defaultValue="overview" className="w-full">
                            <TabsList className="grid w-full grid-cols-4">
                              <TabsTrigger value="overview">Overview</TabsTrigger>
                              <TabsTrigger value="factors">Risk Factors</TabsTrigger>
                              <TabsTrigger value="predictions">Predictions</TabsTrigger>
                              <TabsTrigger value="recommendations">Actions</TabsTrigger>
                            </TabsList>
                            
                            <TabsContent value="overview" className="space-y-4">
                              <div className="grid grid-cols-2 gap-4">
                                <Card>
                                  <CardHeader className="pb-3">
                                    <CardTitle className="text-sm">Overall Risk Score</CardTitle>
                                  </CardHeader>
                                  <CardContent>
                                    <div className="text-3xl font-bold mb-2">{analysis.overallRiskScore}%</div>
                                    <Badge variant={getRiskLevelColor(analysis.riskLevel) as any}>
                                      {analysis.riskLevel} Risk
                                    </Badge>
                                  </CardContent>
                                </Card>
                                
                                <Card>
                                  <CardHeader className="pb-3">
                                    <CardTitle className="text-sm">Active Alerts</CardTitle>
                                  </CardHeader>
                                  <CardContent>
                                    <div className="text-3xl font-bold mb-2">{analysis.alerts.length}</div>
                                    <p className="text-sm text-muted-foreground">Notifications pending</p>
                                  </CardContent>
                                </Card>
                              </div>
                              
                              <div className="space-y-2">
                                <h4 className="font-medium">Student Information</h4>
                                <div className="grid grid-cols-2 gap-4 text-sm">
                                  <div>Roll Number: {analysis.student.rollNumber}</div>
                                  <div>Class: {analysis.student.class}</div>
                                  <div>Stream: {analysis.student.stream}</div>
                                  <div>Year: {analysis.student.year}</div>
                                  <div>Semester: {analysis.student.semester}</div>
                                  <div>Attendance: {analysis.student.attendanceStats.percentage}%</div>
                                </div>
                              </div>
                            </TabsContent>
                            
                            <TabsContent value="factors" className="space-y-4">
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <Card>
                                  <CardHeader className="pb-3">
                                    <CardTitle className="text-sm flex items-center gap-2">
                                      <Clock className="h-4 w-4" />
                                      Attendance Risk
                                    </CardTitle>
                                  </CardHeader>
                                  <CardContent>
                                    <div className="flex items-center gap-2 mb-2">
                                      <Progress value={analysis.riskFactors.attendance} className="flex-1" />
                                      <span className="text-sm font-medium">{analysis.riskFactors.attendance}%</span>
                                    </div>
                                    <p className="text-xs text-muted-foreground">
                                      Current attendance: {analysis.student.attendanceStats.percentage}%
                                    </p>
                                  </CardContent>
                                </Card>
                                
                                <Card>
                                  <CardHeader className="pb-3">
                                    <CardTitle className="text-sm flex items-center gap-2">
                                      <BookOpen className="h-4 w-4" />
                                      Academic Risk
                                    </CardTitle>
                                  </CardHeader>
                                  <CardContent>
                                    <div className="flex items-center gap-2 mb-2">
                                      <Progress value={analysis.riskFactors.academicPerformance} className="flex-1" />
                                      <span className="text-sm font-medium">{analysis.riskFactors.academicPerformance}%</span>
                                    </div>
                                    <p className="text-xs text-muted-foreground">
                                      Average marks: {Math.round(analysis.student.grades.reduce((sum, g) => sum + g.marks, 0) / analysis.student.grades.length)}%
                                    </p>
                                  </CardContent>
                                </Card>
                                
                                <Card>
                                  <CardHeader className="pb-3">
                                    <CardTitle className="text-sm flex items-center gap-2">
                                      <TrendingDown className="h-4 w-4" />
                                      Trend Analysis
                                    </CardTitle>
                                  </CardHeader>
                                  <CardContent>
                                    <div className="flex items-center gap-2 mb-2">
                                      <Progress value={analysis.riskFactors.trendAnalysis} className="flex-1" />
                                      <span className="text-sm font-medium">{analysis.riskFactors.trendAnalysis}%</span>
                                    </div>
                                    <p className="text-xs text-muted-foreground">
                                      Performance trend analysis
                                    </p>
                                  </CardContent>
                                </Card>
                                
                                <Card>
                                  <CardHeader className="pb-3">
                                    <CardTitle className="text-sm flex items-center gap-2">
                                      <Target className="h-4 w-4" />
                                      Subject Consistency
                                    </CardTitle>
                                  </CardHeader>
                                  <CardContent>
                                    <div className="flex items-center gap-2 mb-2">
                                      <Progress value={analysis.riskFactors.subjectConsistency} className="flex-1" />
                                      <span className="text-sm font-medium">{analysis.riskFactors.subjectConsistency}%</span>
                                    </div>
                                    <p className="text-xs text-muted-foreground">
                                      Grade variance across subjects
                                    </p>
                                  </CardContent>
                                </Card>
                              </div>
                            </TabsContent>
                            
                            <TabsContent value="predictions" className="space-y-4">
                              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                <Card>
                                  <CardHeader className="pb-3">
                                    <CardTitle className="text-sm text-red-600">Dropout Risk</CardTitle>
                                  </CardHeader>
                                  <CardContent>
                                    <div className="text-2xl font-bold mb-2">{analysis.predictions.dropoutRisk}%</div>
                                    <Progress value={analysis.predictions.dropoutRisk} className="mb-2" />
                                    <p className="text-xs text-muted-foreground">
                                      Probability of student dropout
                                    </p>
                                  </CardContent>
                                </Card>
                                
                                <Card>
                                  <CardHeader className="pb-3">
                                    <CardTitle className="text-sm text-orange-600">Backlog Risk</CardTitle>
                                  </CardHeader>
                                  <CardContent>
                                    <div className="text-2xl font-bold mb-2">{analysis.predictions.backlogRisk}%</div>
                                    <Progress value={analysis.predictions.backlogRisk} className="mb-2" />
                                    <p className="text-xs text-muted-foreground">
                                      Risk of subject backlogs
                                    </p>
                                  </CardContent>
                                </Card>
                                
                                <Card>
                                  <CardHeader className="pb-3">
                                    <CardTitle className="text-sm text-yellow-600">Low Grade Risk</CardTitle>
                                  </CardHeader>
                                  <CardContent>
                                    <div className="text-2xl font-bold mb-2">{analysis.predictions.lowGradeRisk}%</div>
                                    <Progress value={analysis.predictions.lowGradeRisk} className="mb-2" />
                                    <p className="text-xs text-muted-foreground">
                                      Risk of poor academic performance
                                    </p>
                                  </CardContent>
                                </Card>
                              </div>
                              
                              {analysis.alerts.length > 0 && (
                                <div className="space-y-2">
                                  <h4 className="font-medium">Active Alerts</h4>
                                  <div className="space-y-2">
                                    {analysis.alerts.map((alert, index) => (
                                      <Alert key={index} className={alert.type === 'danger' ? 'border-red-200' : 'border-yellow-200'}>
                                        <AlertTriangle className="h-4 w-4" />
                                        <AlertTitle className="flex items-center justify-between">
                                          Alert #{index + 1}
                                          <Badge variant={alert.priority === 'urgent' ? 'destructive' : 'secondary'}>
                                            {alert.priority}
                                          </Badge>
                                        </AlertTitle>
                                        <AlertDescription>{alert.message}</AlertDescription>
                                      </Alert>
                                    ))}
                                  </div>
                                </div>
                              )}
                            </TabsContent>
                            
                            <TabsContent value="recommendations" className="space-y-4">
                              <div className="space-y-4">
                                <div className="flex items-center gap-2">
                                  <Lightbulb className="h-5 w-5 text-yellow-500" />
                                  <h4 className="font-medium">AI Recommendations</h4>
                                </div>
                                
                                <div className="space-y-2">
                                  {analysis.recommendations.map((recommendation, index) => (
                                    <Card key={index} className="border-l-4 border-l-blue-500">
                                      <CardContent className="p-4">
                                        <p className="text-sm">{recommendation}</p>
                                      </CardContent>
                                    </Card>
                                  ))}
                                </div>
                                
                                <div className="pt-4 border-t">
                                  <h5 className="font-medium mb-2">Suggested Actions</h5>
                                  <div className="space-y-2">
                                    <Button size="sm" variant="outline" className="gap-2 mr-2">
                                      <MessageSquare className="h-4 w-4" />
                                      Contact Parent
                                    </Button>
                                    <Button size="sm" variant="outline" className="gap-2 mr-2">
                                      <Users className="h-4 w-4" />
                                      Schedule Counseling
                                    </Button>
                                    <Button size="sm" variant="outline" className="gap-2">
                                      <BookOpen className="h-4 w-4" />
                                      Academic Support
                                    </Button>
                                  </div>
                                </div>
                              </div>
                            </TabsContent>
                          </Tabs>
                        </DialogContent>
                      </Dialog>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
          
          {filteredAnalyses.length === 0 && (
            <div className="text-center py-8 text-muted-foreground">
              <Brain className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>No students match your current filters.</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
  } catch (error) {
    console.error('AI Performance Predictor Render Error:', error);
    return (
      <div className="space-y-6">
        <Card className="border-red-200 bg-red-50">
          <CardHeader>
            <CardTitle className="text-red-800 flex items-center gap-2">
              <AlertTriangle className="h-5 w-5" />
              Rendering Error
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-red-700">
              The AI Performance Predictor encountered an error while rendering. 
              Please try refreshing the page or contact support if the issue persists.
            </p>
            <Button 
              onClick={() => window.location.reload()} 
              variant="outline" 
              className="mt-4"
            >
              Refresh Page
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }
}