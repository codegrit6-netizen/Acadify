import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { 
  BookOpen, 
  Users, 
  Target, 
  TrendingUp, 
  CheckCircle,
  QrCode,
  Wifi,
  Calendar,
  UserCheck
} from 'lucide-react';

export function ProjectInfo() {
  const expectedOutcomes = [
    {
      icon: <QrCode className="w-5 h-5" />,
      title: "Automatic Attendance",
      description: "Marks student attendance based on daily timetable using QR code, Bluetooth/Wi-Fi proximity, or face recognition"
    },
    {
      icon: <UserCheck className="w-5 h-5" />,
      title: "Real-time Display",
      description: "Displays real-time attendance on classroom screens for immediate visibility"
    },
    {
      icon: <Target className="w-5 h-5" />,
      title: "Personalized Tasks",
      description: "Suggests academic tasks during free periods based on student interests, strengths, and career goals"
    },
    {
      icon: <Calendar className="w-5 h-5" />,
      title: "Daily Routine Generation",
      description: "Creates comprehensive daily routines combining class schedule, free time, and long-term personal goals"
    }
  ];

  const stakeholders = [
    "Students",
    "Teachers", 
    "College Administrators",
    "Career Counselors",
    "Education Departments"
  ];

  return (
    <div className="space-y-4 lg:space-y-6 p-4 lg:p-6">
      {/* Header */}
      <div className="text-center mb-6 lg:mb-8">
        <h1 className="gradient-text mb-3 lg:mb-4 text-xl lg:text-2xl">Acadify - Smart Curriculum Activity & Attendance App</h1>
        <p className="text-muted-foreground max-w-3xl mx-auto text-sm lg:text-base px-2">
          Revolutionizing educational attendance systems and student productivity through intelligent automation and personalized learning support.
        </p>
      </div>

      {/* Problem Description */}
      <Card className="glass-effect">
        <CardHeader>
          <CardTitle className="flex items-center gap-3">
            <BookOpen className="w-6 h-6 text-primary" />
            Problem Description
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 lg:space-y-4">
          <p className="text-sm lg:text-base">
            Many educational institutions still depend on manual attendance systems, which are time-consuming and error-prone. 
            Teachers spend a significant portion of class time marking attendance, reducing valuable instructional hours.
          </p>
          <p className="text-sm lg:text-base">
            Additionally, students often waste free periods with unproductive activities due to a lack of structured guidance. 
            This leads to poor time management and reduced alignment with long-term academic or career goals.
          </p>
          <p className="text-sm lg:text-base">
            There is also a gap in personalized learning support during idle classroom hours. Institutions currently lack 
            tools that integrate daily schedules with individual student planning and automated tracking.
          </p>
        </CardContent>
      </Card>

      {/* Impact */}
      <Card className="glass-effect">
        <CardHeader>
          <CardTitle className="flex items-center gap-3">
            <TrendingUp className="w-6 h-6 text-primary" />
            Impact / Why This Problem Needs to be Solved
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 lg:space-y-4">
          <p className="text-sm lg:text-base">
            This issue impacts both administrative efficiency and student development. Automating attendance saves teachers' 
            time and ensures more accurate records.
          </p>
          <p className="text-sm lg:text-base">
            Additionally, providing students with structured personal development activities during free time helps improve 
            productivity, goal clarity, and learning outcomes.
          </p>
          <p className="text-sm lg:text-base">
            Institutions can also gain better insight into student behavior and engagement, allowing for more targeted support.
          </p>
        </CardContent>
      </Card>

      {/* Expected Outcomes */}
      <Card className="glass-effect">
        <CardHeader>
          <CardTitle className="flex items-center gap-3">
            <CheckCircle className="w-6 h-6 text-primary" />
            Expected Outcomes
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-3 lg:gap-4 md:grid-cols-2">
            {expectedOutcomes.map((outcome, index) => (
              <div key={index} className="flex gap-3 p-3 lg:p-4 rounded-lg bg-accent/30 border border-border/50">
                <div className="text-primary mt-1 flex-shrink-0">
                  {outcome.icon}
                </div>
                <div className="min-w-0">
                  <h4 className="font-medium mb-1 lg:mb-2 text-sm lg:text-base">{outcome.title}</h4>
                  <p className="text-muted-foreground text-xs lg:text-sm">{outcome.description}</p>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-4 lg:mt-6 p-3 lg:p-4 rounded-lg bg-secondary/30 border border-border/50">
            <p className="text-center text-sm lg:text-base">
              <strong>Minimal Infrastructure Required:</strong> The app will require minimal infrastructure and be usable 
              by both students and staff with basic training.
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Stakeholders */}
      <Card className="glass-effect">
        <CardHeader>
          <CardTitle className="flex items-center gap-3">
            <Users className="w-6 h-6 text-primary" />
            Relevant Stakeholders / Beneficiaries
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-2">
            {stakeholders.map((stakeholder, index) => (
              <Badge key={index} variant="secondary" className="px-2 lg:px-3 py-1 text-xs lg:text-sm">
                {stakeholder}
              </Badge>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Supporting Data */}
      <Card className="glass-effect">
        <CardHeader>
          <CardTitle className="flex items-center gap-3">
            <Wifi className="w-6 h-6 text-primary" />
            Supporting Data
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm lg:text-base">
            Surveys and reports on classroom time usage, student productivity, and NEP 2020 recommendations emphasizing 
            personalized and experiential learning provide the foundation for this initiative.
          </p>
          <div className="mt-3 lg:mt-4 p-3 lg:p-4 rounded-lg bg-accent/20 border border-border/50">
            <p className="text-center italic text-sm lg:text-base">
              "The National Education Policy 2020 emphasizes the need for personalized and experiential learning 
              approaches to enhance student engagement and outcomes."
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}