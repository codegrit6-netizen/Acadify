import React, { useState, useEffect } from "react";
import { Button } from "./ui/button";
import acadifyLogo from "figma:asset/ac242b88a3828f6beae2b12715e6e0c50cb74ea8.png";

interface WelcomeScreenProps {
  onGetStarted: () => void;
}

export function WelcomeScreen({ onGetStarted }: WelcomeScreenProps) {
  const [showLogo, setShowLogo] = useState(false);
  const [showText, setShowText] = useState(false);
  const [showButton, setShowButton] = useState(false);

  useEffect(() => {
    // Animation sequence: logo → text → button with enhanced timing
    const logoTimer = setTimeout(() => setShowLogo(true), 400);
    const textTimer = setTimeout(() => setShowText(true), 1000);
    const buttonTimer = setTimeout(() => setShowButton(true), 1600);

    return () => {
      clearTimeout(logoTimer);
      clearTimeout(textTimer);
      clearTimeout(buttonTimer);
    };
  }, []);

  return (
    <div className="min-h-screen flex items-center justify-center relative overflow-hidden" 
         style={{ background: 'var(--background)' }}>
      
      {/* Enhanced light purple gradient background */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-gradient-to-br from-purple-50/70 via-indigo-50/40 to-violet-50/60" />
        <div className="absolute inset-0 bg-gradient-to-tr from-indigo-100/30 via-transparent to-purple-100/40" />
        
        {/* Subtle animated background elements */}
        <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-purple-200/10 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-indigo-200/10 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />
      </div>
      
      {/* Centered content container */}
      <div className="relative z-10 flex flex-col items-center justify-center text-center px-6 max-w-2xl mx-auto">
        
        {/* Logo with enhanced fade-in, scale and float animation */}
        <div className={`mb-20 transition-all duration-1000 ease-out transform ${
          showLogo 
            ? 'opacity-100 translate-y-0 scale-100' 
            : 'opacity-0 translate-y-12 scale-75'
        }`}>
          <div className="relative">
            {/* Subtle glow effect behind logo */}
            <div className="absolute inset-0 bg-gradient-to-r from-purple-400/20 to-indigo-400/20 rounded-full blur-xl scale-150" />
            <img 
              src={acadifyLogo} 
              alt="Acadify Logo" 
              className="w-40 h-auto mx-auto relative z-10 drop-shadow-2xl"
            />
          </div>
        </div>

        {/* Text content with enhanced animations and colors */}
        <div className={`mb-20 transition-all duration-1000 ease-out transform ${
          showText 
            ? 'opacity-100 translate-y-0 scale-100' 
            : 'opacity-0 translate-y-12 scale-95'
        }`}>
          {/* Main headline with gradient text */}
          <h1 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-indigo-600 via-purple-600 to-violet-600 bg-clip-text text-transparent leading-tight">
            Welcome to Acadify
          </h1>
          
          {/* Subline with colorful gradient */}
          <p className="text-xl md:text-2xl font-medium bg-gradient-to-r from-indigo-500 via-purple-500 to-blue-500 bg-clip-text text-transparent">
            Managing Academics Simplified
          </p>
          
          {/* Decorative underline */}
          <div className="mt-6 mx-auto w-24 h-1 bg-gradient-to-r from-transparent via-purple-400 to-transparent rounded-full opacity-60" />
        </div>

        {/* Get Started button with enhanced entrance animation */}
        <div className={`transition-all duration-1000 ease-out transform ${
          showButton 
            ? 'opacity-100 translate-y-0 scale-100' 
            : 'opacity-0 translate-y-12 scale-90'
        }`}>
          <Button 
            onClick={onGetStarted}
            className="px-10 py-5 text-xl font-semibold rounded-2xl shadow-2xl hover:shadow-purple-500/25 transform hover:scale-105 hover:-translate-y-1 transition-all duration-300 border-0"
            className="gradient-shift-btn"
            style={{
              background: 'linear-gradient(135deg, var(--primary) 0%, var(--accent) 50%, var(--primary) 100%)',
              color: 'var(--primary-foreground)',
              backgroundSize: '200% 200%'
            }}
          >
            Get Started
          </Button>
        </div>
      </div>


    </div>
  );
}