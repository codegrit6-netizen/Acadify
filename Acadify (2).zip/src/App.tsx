import React, { useState } from "react";
import { WelcomeScreen } from "./components/WelcomeScreen";
import { LoginForm } from "./components/auth/LoginForm";
import { DashboardLayout } from "./components/layout/DashboardLayout";
import { StudentDashboard } from "./components/dashboards/StudentDashboard";
import { TeacherDashboard } from "./components/dashboards/TeacherDashboard";
import { AdminDashboard } from "./components/dashboards/AdminDashboard";
import { ParentDashboard } from "./components/dashboards/ParentDashboard";
import { ProjectInfo } from "./components/ProjectInfo";
import {
  getUserById,
  demoCredentials,
} from "./data/mockDatabase";
import type {
  Student,
  Teacher,
  Parent,
  Admin,
} from "./data/mockDatabase";

type User = Student | Teacher | Parent | Admin;

export default function App() {
  const [showWelcome, setShowWelcome] = useState(true);
  const [user, setUser] = useState<User | null>(null);
  const [activeTab, setActiveTab] = useState("dashboard");

  const handleLogin = (
    userType: string,
    userId: string,
    password: string,
  ) => {
    // Convert singular userType to plural for demoCredentials lookup
    const userTypePlural = userType + "s";

    // Validate credentials against demo database
    const userTypeCredentials =
      demoCredentials[
        userTypePlural as keyof typeof demoCredentials
      ];
    const validUser = userTypeCredentials?.find(
      (cred) =>
        cred.id === userId && cred.password === password,
    );

    if (validUser) {
      // Get full user data from database
      const fullUser = getUserById(userId, userType);
      if (fullUser && fullUser.type === userType) {
        setUser(fullUser);
        setActiveTab("dashboard");
        return true;
      }
    }

    // Invalid credentials
    return false;
  };

  const handleLogout = () => {
    setUser(null);
    setActiveTab("dashboard");
    setShowWelcome(true);
  };

  const handleGetStarted = () => {
    setShowWelcome(false);
  };

  const renderDashboard = () => {
    if (!user) return null;

    // Handle common tabs first
    if (activeTab === "project-info") {
      return <ProjectInfo />;
    }

    // Handle user-specific tabs
    switch (user.type) {
      case "student":
        return (
          <StudentDashboard
            activeTab={activeTab}
            studentId={user.id}
          />
        );
      case "teacher":
        return (
          <TeacherDashboard
            activeTab={activeTab}
            teacherId={user.id}
          />
        );
      case "admin":
        return (
          <AdminDashboard
            activeTab={activeTab}
            adminId={user.id}
          />
        );
      case "parent":
        return (
          <ParentDashboard
            activeTab={activeTab}
            parentId={user.id}
          />
        );
      default:
        return null;
    }
  };

  // Show welcome screen first
  if (showWelcome) {
    return <WelcomeScreen onGetStarted={handleGetStarted} />;
  }

  // Show login form if not logged in
  if (!user) {
    return <LoginForm onLogin={handleLogin} />;
  }

  return (
    <DashboardLayout
      user={user}
      onLogout={handleLogout}
      activeTab={activeTab}
      onTabChange={setActiveTab}
    >
      {renderDashboard()}
    </DashboardLayout>
  );
}